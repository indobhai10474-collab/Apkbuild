# DraftStudio — AI Animation & 2D Editing Studio

An original, **100% on-device** 2D animation editor with AI-assisted character
generation, backgrounds, and voiceover with automatic lip-sync.

- **No subscription. No credits. No watermark. No internet required.**
- Everything runs on your phone: procedural character/background generation,
  Android TextToSpeech voiceover, MediaCodec H.264 MP4 export, GIF/PNG export.

## Features

### Animation Editor
- Timeline with keyframes (X, Y, scale, rotation, opacity, lip-sync)
- Easing presets: linear, easeIn, easeOut, easeInOut, hold
- 10+ animation presets: Slide In, Bounce In, Walk Cycle, Jump, Spin, Pulse, Shake, Pop In, Idle Breathing, Fade
- Layers: characters, props, text, effects — reorder, duplicate, hide, lock
- Camera keyframes (pan/zoom) per scene
- Multiple scenes per project, JSON project files (portable/shareable)

### AI (on-device)
- **AI Character Generator** — procedural characters: body/skin/outfit colors,
  6 emotions, props (hat, glasses, crown, mic, sword). Deterministic per seed,
  instant and unlimited.
- **AI Background Generator** — procedural skies: gradients, starry night,
  mountain landscapes with fractal terrain. Seed-randomized.
- **AI Voiceover** — Android TTS → PCM → audio layer, with **automatic
  lip-sync** baked into the character's LIP track (envelope detection).

### Export
- MP4 (H.264) via MediaCodec — offline, saved to Movies/DraftStudio
- Animated GIF (pure-Kotlin LZW encoder)
- PNG frame sequence
- WAV narration mix (voiceover + lip-sync)

## Tech

- Kotlin + Jetpack Compose (Material 3)
- No third-party SDKs; rendering via `android.graphics.Canvas` shared between
  live preview and exporters (what you see is what you export)
- Min SDK 24, target 35

## Build (Sirf Phone Se — No Computer Needed)

Tumhe sirf 2 files upload karni hain aur GitHub ka free cloud APK bana dega.
Koi command, koi `git push`, koi coding nahi — sirf browser me tap-tap.

### Step 1 — GitHub account banao (agar nahi hai)
1. Phone browser me `github.com` kholo.
2. **Sign up** → apna email + password + username bharo.
3. Email verification karo (GitHub ki mail me **Verify** dabao).

### Step 2 — Naya repository banao
1. GitHub home par **"+"** icon (upar right) → **New repository**.
2. Repository name me likho: `DraftStudio` (koi bhi naam chalega).
3. **Public** chuno (Private me bhi chalega).
4. **"Create repository"** dabao.

### Step 3 — Files upload karo
1. Naye page me **"uploading an existing file"** link par tap karo.
2. In 2 files ko select karo (dono `/storage/emulated/0/MT2/apks/` me hain):
   - `DraftStudio-source.tar.gz`
   - `build-apk.yml`
3. **Commit changes** dabao (message chhod do, zaroori nahi).

### Step 4 — Workflow ko sahi jagah rakho
Upload ke baad root me 2 cheezein dikhengi: `DraftStudio-source.tar.gz` aur `build-apk.yml`.
Ab `build-apk.yml` ko `.github/workflows/` folder me move karna hoga:

1. GitHub repo page par **`build-apk.yml`** par tap karo.
2. **Edit** (pencil icon) dabao.
3. File path wale box me path badal do:
   `build-apk.yml` → `.github/workflows/build-apk.yml`
4. **Commit changes** dabao.

### Step 5 — Build chalao
1. Repo ke upar **"Actions"** tab par tap karo.
2. Left me **"Build APK"** par tap karo.
3. **"Run workflow"** button → green **"Run workflow"** confirm karo.
4. ~3-5 min ruko. Jab khatam ho, **"Build APK"** par tap karo → niche **Artifacts** me `draftstudio-debug-apk` dikhega.

### Step 6 — APK download + install
1. `draftstudio-debug-apk` par tap karo → `.zip` download hoga.
2. Phone ke Files app me kholo → `app-debug.apk` nikal lo.
3. Us par tap karo → **Install** (pehli baar "Install unknown apps" allow karna hoga).

Bas! Ab DraftStudio tumhare Realme C55 par hai — bilkul free, offline, unlimited.

---

### Option B: Android Studio (PC ho to)
1. Open `DraftStudio/` in Android Studio (Iguana or newer).
2. Let Gradle sync (AGP 8.5.2, JDK 17).
3. `Build → Generate Signed App Bundle / APK` (or just Run on your device).

## How to use
1. **New Project** → opens the editor (1280x720 @ 30fps).
2. **AI Character** tab → pick style/emotion/prop/colors → *Add to Scene*.
3. **AI Bg** tab → choose a landscape → *Use as Scene Background*.
4. Select the layer, use **Properties** tab:
   - Drag on canvas to move it
   - Sliders change transform
   - **Set Key** bakes all transform values at the playhead
   - **Animation Presets** adds a ready-made motion to the timeline
5. **Voice** tab → type dialogue → *Generate Voiceover* → *Add to Scene*
   (auto lip-syncs the selected character).
6. **Export** → MP4 / GIF / PNG.

## Project structure

```
app/src/main/java/com/draftstudio/app/
  model/       Project/Scene/Layer/Track/Keyframe (JSON-serializable)
  core/        Timeline evaluator, easing, commands, presets, store
  render/      SceneRenderer (characters, props, text, effects, backgrounds)
  export/      MP4 (MediaCodec), GIF (LZW), PNG, WAV mixer
  ai/          TTS voiceover engine + lip-sync analyzer
  ui/          Compose screens (home, editor, AI, voiceover, export)
```

## License
Original code — yours to use, modify, and distribute. All artwork generated
procedurally at runtime; no bundled third-party assets.
