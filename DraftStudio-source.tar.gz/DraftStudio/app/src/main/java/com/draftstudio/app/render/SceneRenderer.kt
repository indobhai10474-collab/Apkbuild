package com.draftstudio.app.render

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.draftstudio.app.core.FrameState
import com.draftstudio.app.core.Noise
import com.draftstudio.app.core.Timeline
import com.draftstudio.app.core.Tracks
import com.draftstudio.app.model.Appearance
import com.draftstudio.app.model.Layer
import com.draftstudio.app.model.LayerType
import com.draftstudio.app.model.Scene
import com.draftstudio.app.model.SceneBackground
import com.draftstudio.app.model.TextAppearance
import com.draftstudio.app.model.TrackType
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * SceneRenderer draws a full scene to any Canvas at any frame.
 * The same code path is used by the live preview (Compose) and by
 * exporters (PNG frames → MP4/GIF), so what you see is what you export.
 */
object SceneRenderer {

    fun render(
        canvas: Canvas,
        scene: Scene,
        frame: Float,
        sceneW: Float,
        sceneH: Float,
    ) {
        // ---- background ----
        drawBackground(canvas, scene.background, sceneW, sceneH)

        // ---- layers in order (bottom → top) ----
        for (layer in scene.layers.sortedBy { it.layerOrder }) {
            if (!layer.visible) continue
            val state = Timeline.evaluate(layer, frame)
            if (state.opacity <= 0.001f) continue
            canvas.save()
            // scene-space transform: layer position + camera
            val cam = Timeline.cameraView(scene, frame)
            val ox = sceneW / 2f
            val oy = sceneH / 2f
            canvas.translate(ox, oy)
            canvas.scale(cam.zoom, cam.zoom)
            canvas.rotate(cam.rotation)
            canvas.translate(-cam.x * cam.zoom, -cam.y * cam.zoom)
            canvas.translate(-ox, -oy)

            canvas.save()
            canvas.translate(state.x, state.y)
            canvas.rotate(state.rotation)
            canvas.scale(state.scaleX, state.scaleY)
            if (state.opacity < 0.999f) {
                // apply global layer alpha: draw into an offscreen bitmap then
                // blit with alpha so every paint (including fills) fades.
                val bw = 1280
                val bh = 720
                val off = android.graphics.Bitmap.createBitmap(bw, bh, android.graphics.Bitmap.Config.ARGB_8888)
                val oc = Canvas(off)
                // reapply transform before content? Instead render content into
                // the offscreen with the layer transform zeroed, then draw the
                // offscreen onto the canvas at the layer position.
                drawLayerContent(oc, layer, state, frame)
                val alpha = (state.opacity * 255).toInt().coerceIn(0, 255)
                val p = Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                p.alpha = alpha
                canvas.drawBitmap(off, 0f, 0f, p)
                off.recycle()
            } else {
                drawLayerContent(canvas, layer, state, frame)
            }

            canvas.restore()
            canvas.restore()
        }
    }

    private fun drawLayerContent(canvas: Canvas, layer: Layer, state: FrameState, frame: Float) {
        when (layer.type) {
            LayerType.BACKGROUND -> { /* scene background handles this */ }
            LayerType.CHARACTER -> drawCharacter(canvas, layer, state, frame)
            LayerType.PROP -> drawProp(canvas, layer, state, frame)
            LayerType.TEXT -> drawText(canvas, layer, state, frame)
            LayerType.EFFECT -> drawEffect(canvas, layer, state, frame)
            LayerType.AUDIO -> { /* no visual */ }
        }
    }

    // ==================== BACKGROUND ====================

    fun drawBackground(canvas: Canvas, bg: SceneBackground, w: Float, h: Float) {
        when (bg.type) {
            "solid" -> {
                val p = Paint().apply { color = bg.color.toInt() }
                canvas.drawRect(0f, 0f, w, h, p)
            }
            "stars" -> drawStars(canvas, bg, w, h)
            "mountains" -> drawMountains(canvas, bg, w, h)
            else -> drawGradient(canvas, bg, w, h)
        }
    }

    private fun drawGradient(canvas: Canvas, bg: SceneBackground, w: Float, h: Float) {
        val p = Paint()
        val shader = android.graphics.LinearGradient(
            0f, 0f, w * cos(bg.gradientAngle), h * sin(bg.gradientAngle),
            bg.colorTop.toInt(), bg.colorBottom.toInt(),
            android.graphics.Shader.TileMode.CLAMP,
        )
        p.shader = shader
        canvas.drawRect(0f, 0f, w, h, p)
    }

    private fun drawStars(canvas: Canvas, bg: SceneBackground, w: Float, h: Float) {
        // night sky gradient + stars
        val p = Paint()
        p.shader = android.graphics.LinearGradient(
            0f, 0f, 0f, h,
            0xFF0D1440.toInt(), 0xFF201A30.toInt(),
            android.graphics.Shader.TileMode.CLAMP,
        )
        canvas.drawRect(0f, 0f, w, h, p)
        val star = Paint()
        star.color = Color.WHITE
        val count = 90
        for (i in 0 until count) {
            val x = Noise.rand(bg.seed, i, 0f, w)
            val y = Noise.rand(bg.seed, i + 1000, 0f, h * 0.6f)
            val r = Noise.rand(bg.seed, i + 2000, 0.8f, 2.6f)
            star.alpha = (Noise.rand(bg.seed, i + 3000, 100f, 255f)).toInt()
            canvas.drawCircle(x, y, r, star)
        }
        // ground
        val g = Paint()
        g.color = 0xFF0B0F24.toInt()
        canvas.drawRect(0f, h * 0.72f, w, h, g)
    }

    private fun drawMountains(canvas: Canvas, bg: SceneBackground, w: Float, h: Float) {
        // sky
        val p = Paint()
        p.shader = android.graphics.LinearGradient(
            0f, 0f, 0f, h,
            0xFF87CEEB.toInt(), 0xFFFFE0B2.toInt(),
            android.graphics.Shader.TileMode.CLAMP,
        )
        canvas.drawRect(0f, 0f, w, h, p)
        // sun
        val sun = Paint()
        sun.color = 0xFFFFD54F.toInt()
        canvas.drawCircle(w * 0.8f, h * 0.25f, 60f, sun)
        // mountain layers using fbm
        drawRidge(canvas, w, h, bg.seed, h * 0.55f, 0xFF5D4037.toInt(), 140f)
        drawRidge(canvas, w, h, bg.seed + 7, h * 0.65f, 0xFF4E342E.toInt(), 120f)
        drawRidge(canvas, w, h, bg.seed + 13, h * 0.75f, 0xFF3E2723.toInt(), 100f)
    }

    private fun drawRidge(canvas: Canvas, w: Float, h: Float, seed: Int, baseY: Float, color: Int, amp: Float) {
        val path = Path()
        val steps = 80
        val step = w / steps
        path.moveTo(0f, h)
        for (i in 0..steps) {
            val x = i * step
            val n = Noise.fbm(seed, x * 0.002f, baseY * 0.01f, 4)
            val y = baseY - amp * n + (i % 5) * 0f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.lineTo(w, h)
        path.close()
        val p = Paint()
        p.color = color
        p.style = Paint.Style.FILL
        canvas.drawPath(path, p)
    }

    // ==================== CHARACTERS ====================

    fun drawCharacter(canvas: Canvas, layer: Layer, state: FrameState, frame: Float) {
        val a = layer.appearance
        // emotion affects face; lipOpen drives mouth
        val p = Paint()
        val w = 220f
        val h = 380f
        canvas.save()
        canvas.scale(1f / 1f, 1f / 1f)
        // body center at origin; draw upward
        // legs
        drawLegs(canvas, p, a, frame, w, h)
        // body
        drawBody(canvas, p, a, w, h)
        // arms
        drawArms(canvas, p, a, frame, w, h)
        // head
        drawHead(canvas, p, a, state, frame, w, h)
        canvas.restore()
    }

    private fun drawLegs(canvas: Canvas, p: Paint, a: Appearance, frame: Float, w: Float, h: Float) {
        val legColor = a.accent
        val legW = 34f
        val legH = 90f
        val gap = 16f
        val baseY = h * 0.5f
        val step = sin(frame * 0.35f)
        // left leg
        val lx = -gap / 2f - legW / 2f
        val ly = baseY + step * 14f
        p.color = legColor.toInt()
        canvas.save()
        canvas.translate(lx, ly)
        canvas.rotate(step * 10f)
        canvas.drawRoundRect(-legW / 2f, -legH, legW / 2f, 0f, 12f, 12f, p)
        canvas.restore()
        // right leg (opposite phase)
        val rx = gap / 2f + legW / 2f
        val ry = baseY - step * 14f
        canvas.save()
        canvas.translate(rx, ry)
        canvas.rotate(-step * 10f)
        canvas.drawRoundRect(-legW / 2f, -legH, legW / 2f, 0f, 12f, 12f, p)
        canvas.restore()
    }

    private fun drawBody(canvas: Canvas, p: Paint, a: Appearance, w: Float, h: Float) {
        val bodyW = 120f
        val bodyH = 150f
        val bodyY = h * 0.42f
        p.color = a.color.toInt()
        val r = RectF(-bodyW / 2f, bodyY - bodyH, bodyW / 2f, bodyY)
        canvas.drawRoundRect(r, 30f, 30f, p)
        // belly accent
        p.color = a.skin.toInt()
        canvas.drawOval(RectF(-bodyW * 0.28f, bodyY - bodyH * 0.7f, bodyW * 0.28f, bodyY - bodyH * 0.15f), p)
    }

    private fun drawArms(canvas: Canvas, p: Paint, a: Appearance, frame: Float, w: Float, h: Float) {
        val armW = 26f
        val armH = 80f
        val shoulderY = h * 0.44f
        val swing = sin(frame * 0.35f) * 18f
        p.color = a.color.toInt()
        // left arm
        canvas.save()
        canvas.translate(-w * 0.34f, shoulderY)
        canvas.rotate(swing + 20f)
        canvas.drawRoundRect(-armW / 2f, -armH, armW / 2f, 0f, 12f, 12f, p)
        canvas.restore()
        // right arm
        canvas.save()
        canvas.translate(w * 0.34f, shoulderY)
        canvas.rotate(-swing - 20f)
        canvas.drawRoundRect(-armW / 2f, -armH, armW / 2f, 0f, 12f, 12f, p)
        canvas.restore()
        // hands
        p.color = a.skin.toInt()
        canvas.drawCircle(-w * 0.34f + sin(frame * 0.35f + 0.5f) * 14f, shoulderY - armH + 6f, 14f, p)
        canvas.drawCircle(w * 0.34f - sin(frame * 0.35f + 0.5f) * 14f, shoulderY - armH + 6f, 14f, p)
    }

    private fun drawHead(canvas: Canvas, p: Paint, a: Appearance, state: FrameState, frame: Float, w: Float, h: Float) {
        val headW = 130f
        val headH = 130f
        val headY = h * 0.46f - 140f
        val cx = 0f
        val cy = headY

        p.color = a.skin.toInt()
        canvas.drawOval(RectF(cx - headW / 2f, cy - headH / 2f, cx + headW / 2f, cy + headH / 2f), p)

        // hair
        p.color = a.accent.toInt()
        canvas.drawArc(RectF(cx - headW / 2f - 4f, cy - headH / 2f - 6f, cx + headW / 2f + 4f, cy + headH / 2f - 20f), 180f, 180f, true, p)

        // eyes
        val eyeY = cy - 12f
        val eyeDX = 26f
        val eyeR = 9f
        p.color = Color.BLACK
        when (a.eyeState) {
            "closed" -> {
                p.strokeWidth = 3f
                p.style = Paint.Style.STROKE
                canvas.drawLine(cx - eyeDX - 8f, eyeY, cx - eyeDX + 8f, eyeY, p)
                canvas.drawLine(cx + eyeDX - 8f, eyeY, cx + eyeDX + 8f, eyeY, p)
                p.style = Paint.Style.FILL
            }
            else -> {
                canvas.drawCircle(cx - eyeDX, eyeY, eyeR, p)
                canvas.drawCircle(cx + eyeDX, eyeY, eyeR, p)
            }
        }

        // eyebrows by emotion
        val brow = Paint()
        brow.color = a.accent.toInt()
        brow.strokeWidth = 4f
        brow.strokeCap = Paint.Cap.ROUND
        when (a.emotion) {
            "angry" -> {
                canvas.drawLine(cx - eyeDX - 8f, eyeY - 18f, cx - eyeDX + 8f, eyeY - 8f, brow)
                canvas.drawLine(cx + eyeDX - 8f, eyeY - 8f, cx + eyeDX + 8f, eyeY - 18f, brow)
            }
            "sad" -> {
                canvas.drawLine(cx - eyeDX - 8f, eyeY - 10f, cx - eyeDX + 8f, eyeY - 16f, brow)
                canvas.drawLine(cx + eyeDX - 8f, eyeY - 16f, cx + eyeDX + 8f, eyeY - 10f, brow)
            }
            "surprised" -> {
                canvas.drawCircle(cx - eyeDX, eyeY - 10f, 3f, brow)
                canvas.drawCircle(cx + eyeDX, eyeY - 10f, 3f, brow)
            }
            "happy", "sleepy" -> {
                canvas.drawArc(RectF(cx - eyeDX - 10f, eyeY - 16f, cx - eyeDX + 10f, eyeY - 6f), 180f, 180f, false, brow)
                canvas.drawArc(RectF(cx + eyeDX - 10f, eyeY - 16f, cx + eyeDX + 10f, eyeY - 6f), 180f, 180f, false, brow)
            }
            else -> {
                canvas.drawLine(cx - eyeDX - 8f, eyeY - 12f, cx - eyeDX + 8f, eyeY - 12f, brow)
                canvas.drawLine(cx + eyeDX - 8f, eyeY - 12f, cx + eyeDX + 8f, eyeY - 12f, brow)
            }
        }

        // mouth with lip sync
        val mouthY = cy + 38f
        val lip = state.lipOpen.coerceIn(0f, 1f)
        val mouthColor = 0xFF8D5524.toInt()
        p.color = mouthColor
        when (a.emotion) {
            "happy" -> canvas.drawArc(RectF(cx - 22f, mouthY - 8f, cx + 22f, mouthY + 18f), 20f, 140f, false, p)
            "sad" -> canvas.drawArc(RectF(cx - 22f, mouthY - 16f, cx + 22f, mouthY + 6f), 200f, 140f, false, p)
            "surprised" -> canvas.drawOval(RectF(cx - 12f, mouthY - 8f, cx + 12f, mouthY + 12f), p)
            else -> {
                if (lip > 0.05f) {
                    canvas.drawOval(RectF(cx - 20f, mouthY - 4f - lip * 10f, cx + 20f, mouthY + 6f + lip * 8f), p)
                } else {
                    canvas.drawLine(cx - 18f, mouthY, cx + 18f, mouthY, p)
                }
            }
        }

        // cheeks
        val cheek = Paint()
        cheek.color = 0x55FF8A80.toInt()
        canvas.drawCircle(cx - eyeDX - 16f, cy + 22f, 12f, cheek)
        canvas.drawCircle(cx + eyeDX + 16f, cy + 22f, 12f, cheek)

        // props
        when (a.prop) {
            "hat" -> drawHat(canvas, p, cx, cy, headW)
            "glasses" -> drawGlasses(canvas, p, cx, cy, eyeDX, eyeY)
            "crown" -> drawCrown(canvas, p, cx, cy, headW)
            "mic" -> drawMic(canvas, p, cx, cy)
            "sword" -> drawSword(canvas, p, cx, cy)
            else -> {}
        }
    }

    private fun drawHat(canvas: Canvas, p: Paint, cx: Float, cy: Float, headW: Float) {
        p.color = 0xFF8D6E63.toInt()
        canvas.drawRoundRect(RectF(cx - headW * 0.7f, cy - headW * 0.55f, cx + headW * 0.7f, cy - headW * 0.35f), 10f, 10f, p)
        p.color = 0xFF6D4C41.toInt()
        canvas.drawRoundRect(RectF(cx - headW * 0.42f, cy - headW * 0.95f, cx + headW * 0.42f, cy - headW * 0.5f), 14f, 14f, p)
    }

    private fun drawGlasses(canvas: Canvas, p: Paint, cx: Float, cy: Float, eyeDX: Float, eyeY: Float) {
        p.color = 0xFF37474F.toInt()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        canvas.drawCircle(cx - eyeDX, eyeY, 16f, p)
        canvas.drawCircle(cx + eyeDX, eyeY, 16f, p)
        canvas.drawLine(cx - eyeDX + 16f, eyeY, cx + eyeDX - 16f, eyeY, p)
        p.style = Paint.Style.FILL
    }

    private fun drawCrown(canvas: Canvas, p: Paint, cx: Float, cy: Float, headW: Float) {
        p.color = 0xFFFFD54F.toInt()
        val path = Path()
        val w = headW * 0.45f
        path.moveTo(cx - w, cy - headW * 0.55f)
        path.lineTo(cx - w, cy - headW * 0.85f)
        path.lineTo(cx - w * 0.5f, cy - headW * 0.65f)
        path.lineTo(cx, cy - headW * 0.95f)
        path.lineTo(cx + w * 0.5f, cy - headW * 0.65f)
        path.lineTo(cx + w, cy - headW * 0.85f)
        path.lineTo(cx + w, cy - headW * 0.55f)
        path.close()
        canvas.drawPath(path, p)
    }

    private fun drawMic(canvas: Canvas, p: Paint, cx: Float, cy: Float) {
        p.color = 0xFF37474F.toInt()
        p.strokeWidth = 6f
        canvas.drawLine(cx + 40f, cy - 60f, cx + 40f, cy + 40f, p)
        p.color = 0xFF546E7A.toInt()
        canvas.drawCircle(cx + 40f, cy - 60f, 10f, p)
    }

    private fun drawSword(canvas: Canvas, p: Paint, cx: Float, cy: Float) {
        p.color = 0xFFB0BEC5.toInt()
        p.strokeWidth = 8f
        canvas.drawLine(cx + 55f, cy - 120f, cx + 75f, cy + 40f, p)
        p.color = 0xFFFFD54F.toInt()
        canvas.drawLine(cx + 50f, cy - 130f, cx + 58f, cy - 110f, p)
        p.strokeWidth = 4f
        canvas.drawLine(cx + 58f, cy - 118f, cx + 76f, cy - 108f, p)
        p.strokeWidth = 0f
        p.color = 0xFF795548.toInt()
        canvas.drawRect(RectF(cx + 58f, cy + 36f, cx + 78f, cy + 52f), p)
    }

    // ==================== PROPS ====================

    fun drawProp(canvas: Canvas, layer: Layer, state: FrameState, frame: Float) {
        val a = layer.appearance
        val p = Paint()
        val w = 160f
        val h = 160f
        when (a.prop) {
            "ball" -> {
                p.color = a.color.toInt()
                canvas.drawCircle(0f, 0f, 60f, p)
                p.color = 0x22000000.toInt()
                canvas.drawArc(RectF(-60f, -60f, 60f, 60f), 30f, 60f, false, p)
            }
            "box" -> {
                p.color = a.color.toInt()
                canvas.drawRect(RectF(-60f, -60f, 60f, 60f), p)
                p.color = 0x33000000.toInt()
                canvas.drawRect(RectF(-60f, -60f, 60f, -30f), p)
            }
            "tree" -> {
                p.color = 0xFF8D6E63.toInt()
                canvas.drawRect(RectF(-12f, 0f, 12f, 80f), p)
                p.color = a.color.toInt()
                canvas.drawCircle(0f, -10f, 50f, p)
            }
            "star" -> {
                p.color = a.color.toInt()
                val path = Path()
                val cx = 0f
                val cy = 0f
                val rOuter = 70f
                val rInner = 30f
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) rOuter else rInner
                    val ang = (Math.PI * i / 5).toFloat()
                    val x = cx + r * cos(ang)
                    val y = cy + r * sin(ang)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                canvas.drawPath(path, p)
            }
            else -> {
                p.color = a.color.toInt()
                canvas.drawOval(RectF(-60f, -60f, 60f, 60f), p)
            }
        }
    }

    // ==================== TEXT ====================

    fun drawText(canvas: Canvas, layer: Layer, state: FrameState, frame: Float) {
        val t = layer.text ?: return
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = t.color.toInt()
        p.textSize = t.size
        p.typeface = if (t.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        val align = when (t.align) {
            "left" -> Paint.Align.LEFT
            "right" -> Paint.Align.RIGHT
            else -> Paint.Align.CENTER
        }
        p.textAlign = align
        canvas.drawText(t.content, 0f, 0f, p)
    }

    // ==================== EFFECTS ====================

    fun drawEffect(canvas: Canvas, layer: Layer, state: FrameState, frame: Float) {
        val a = layer.appearance
        val p = Paint()
        val t = frame % 60f
        when (a.prop) {
            "sparkle" -> {
                val cx = 0f
                val cy = 0f
                val count = 20
                for (i in 0 until count) {
                    val phase = (frame * 0.2f + i * 1.7f)
                    val r = (phase % 60f)
                    val x = cx + cos(phase) * (10f + r * 1.5f)
                    val y = cy + sin(phase) * (10f + r * 1.5f)
                    p.color = if (i % 2 == 0) 0xFFFFD54F.toInt() else 0xFFFFF59D.toInt()
                    p.alpha = ((1f - r / 60f) * 255).toInt().coerceIn(0, 255)
                    canvas.drawCircle(x, y, 4f + (i % 3).toFloat(), p)
                }
            }
            "ring" -> {
                val r = (t / 60f) * 120f
                p.color = a.color.toInt()
                p.style = Paint.Style.STROKE
                p.strokeWidth = 8f * (1f - t / 60f)
                p.alpha = ((1f - t / 60f) * 255).toInt().coerceIn(0, 255)
                canvas.drawCircle(0f, 0f, r, p)
                p.style = Paint.Style.FILL
            }
            "rays" -> {
                p.color = a.color.toInt()
                p.alpha = 200
                val count = 12
                for (i in 0 until count) {
                    val ang = (Math.PI * 2 * i / count + t * 0.05f).toFloat()
                    val x1 = cos(ang) * 20f
                    val y1 = sin(ang) * 20f
                    val x2 = cos(ang) * (70f + t * 0.8f)
                    val y2 = sin(ang) * (70f + t * 0.8f)
                    p.strokeWidth = 6f
                    canvas.drawLine(x1, y1, x2, y2, p)
                }
            }
            else -> {}
        }
    }

    fun longToColor(l: Long): Int = l.toInt()
}
