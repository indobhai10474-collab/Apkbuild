package com.draftstudio.app.core

import com.draftstudio.app.model.Layer
import com.draftstudio.app.model.Track
import com.draftstudio.app.model.TrackType
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/** On-device TTS output (see ai/TtsEngine.kt) */
@Serializable
data class VoiceClip(
    val id: String,
    val text: String,
    val fileName: String,
    val durationSeconds: Float,
)

object ProjectStore {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
    }

    fun projectsDir(root: File): File {
        val dir = File(root, "draftstudio/projects").apply { mkdirs() }
        return dir
    }

    fun save(root: File, project: com.draftstudio.app.model.Project) {
        val file = File(projectsDir(root), "${project.id}.json")
        file.writeText(json.encodeToString(com.draftstudio.app.model.Project.serializer(), project))
        projectsDir(root).listFiles()?.let { files ->
            files.filter { it.extension == "json" && it.name != file.name }
                .sortedByDescending { it.lastModified() }
                .drop(30)
                .forEach { it.delete() }
        }
    }

    fun load(root: File, id: String): com.draftstudio.app.model.Project? {
        val file = File(projectsDir(root), "$id.json")
        if (!file.exists()) return null
        return try {
            json.decodeFromString(com.draftstudio.app.model.Project.serializer(), file.readText())
        } catch (t: Throwable) {
            null
        }
    }

    fun list(root: File): List<com.draftstudio.app.model.Project> {
        val dir = projectsDir(root)
        return (dir.listFiles()?.filter { it.extension == "json" }
            ?.mapNotNull { file ->
                try {
                    json.decodeFromString(com.draftstudio.app.model.Project.serializer(), file.readText())
                } catch (t: Throwable) { null }
            }
            ?.sortedByDescending { it.updatedAt } ?: emptyList())
    }

    fun delete(root: File, id: String): Boolean {
        return File(projectsDir(root), "$id.json").delete()
    }

    // ---- voice clip storage ----
    fun voiceDir(root: File): File = File(root, "draftstudio/voice").apply { mkdirs() }
    fun saveVoice(root: File, clip: VoiceClip, pcm: ByteArray) {
        File(voiceDir(root), clip.fileName).writeBytes(pcm)
    }
    fun loadVoice(root: File, clip: VoiceClip): ByteArray? {
        val f = File(voiceDir(root), clip.fileName)
        return if (f.exists()) f.readBytes() else null
    }
    fun deleteVoice(root: File, clip: VoiceClip) {
        File(voiceDir(root), clip.fileName).delete()
    }

    // ---- exports ----
    fun exportsDir(root: File): File = File(root, "draftstudio/exports").apply { mkdirs() }
}

/** Tiny helper for interpolated track lookup. */
object Tracks {
    fun find(layer: Layer, type: TrackType): Track? =
        layer.tracks.firstOrNull { it.property == type }

    fun getFloat(layer: Layer, type: TrackType, default: Float): Float {
        val track = find(layer, type) ?: return default
        val kf = track.keyframes
        if (kf.isEmpty()) return default
        if (kf.size == 1) return kf.first().value
        // value at frame 0 baseline = keyframe at or before frame 0
        val at0 = kf.firstOrNull { it.frame <= 0 }?.value ?: default
        return at0
    }

    fun valueAt(layer: Layer, type: TrackType, frame: Float, default: Float): Float {
        val track = find(layer, type) ?: return default
        val kf = track.keyframes
        if (kf.isEmpty()) return default
        if (kf.size == 1) return kf[0].value
        val sorted = kf.sortedBy { it.frame }
        val first = sorted.first()
        val last = sorted.last()
        if (frame <= first.frame) return first.value
        if (frame >= last.frame) return last.value
        var i = 0
        while (i < sorted.size - 1 && sorted[i + 1].frame < frame) i++
        val a = sorted[i]
        val b = sorted[i + 1]
        val span = (b.frame - a.frame).toFloat()
        var t = if (span <= 0f) 1f else (frame - a.frame) / span
        t = Easing.apply(a.ease, t.coerceIn(0f, 1f))
        return a.value + (b.value - a.value) * t
    }

    /** Camera interpolation. Each camera keyframe stores its value in `value`. */
    fun valueAtForCamera(cam: com.draftstudio.app.model.Camera, frame: Float, default: Float): Float {
        val kf = cam.keyframes
        if (kf.isEmpty()) return default
        if (kf.size == 1) return kf.first().value
        val sorted = kf.sortedBy { it.frame }
        val first = sorted.first()
        val last = sorted.last()
        if (frame <= first.frame) return first.value
        if (frame >= last.frame) return last.value
        var i = 0
        while (i < sorted.size - 1 && sorted[i + 1].frame < frame) i++
        val a = sorted[i]
        val b = sorted[i + 1]
        val span = (b.frame - a.frame).toFloat()
        var t = if (span <= 0f) 1f else (frame - a.frame) / span
        t = Easing.apply(a.ease, t.coerceIn(0f, 1f))
        return a.value + (b.value - a.value) * t
    }
}

object Easing {
    fun apply(ease: String, t: Float): Float = when (ease) {
        "easeIn" -> t * t
        "easeOut" -> 1f - (1f - t) * (1f - t)
        "easeInOut" -> if (t < 0.5f) 2f * t * t else 1f - (-2f * t + 2f) * (-2f * t + 2f) / 2f
        "hold" -> 0f
        else -> t // linear
    }
}
