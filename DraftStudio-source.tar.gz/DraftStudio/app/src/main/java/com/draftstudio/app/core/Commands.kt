package com.draftstudio.app.core

import com.draftstudio.app.model.Keyframe
import com.draftstudio.app.model.Layer
import com.draftstudio.app.model.LayerType
import com.draftstudio.app.model.Scene
import com.draftstudio.app.model.Track
import com.draftstudio.app.model.TrackType
import kotlin.math.abs

/** Commands mutate the model; undo/redo snapshots whole scenes. */
object Commands {
    fun addLayer(scene: Scene, layer: Layer) {
        scene.layers = scene.layers + layer
    }

    fun removeLayer(scene: Scene, id: String) {
        scene.layers = scene.layers.filterNot { it.id == id }
    }

    fun duplicateLayer(scene: Scene, id: String) {
        val idx = scene.layers.indexOfFirst { it.id == id }
        if (idx < 0) return
        val src = scene.layers[idx]
        val copy = src.copy(
            id = "layer_${System.currentTimeMillis()}",
            name = src.name + " copy",
            tracks = src.tracks.map { t -> t.copy(id = "track_${System.currentTimeMillis()}_${t.property}") },
        )
        scene.layers = scene.layers.toMutableList().apply { add(idx + 1, copy) }
    }

    fun reorderLayer(scene: Scene, id: String, direction: Int) {
        val list = scene.layers.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return
        val to = (idx + direction).coerceIn(0, list.size - 1)
        val item = list.removeAt(idx)
        list.add(to, item)
        scene.layers = list
    }

    fun toggleVisible(scene: Scene, id: String) {
        scene.layers = scene.layers.map {
            if (it.id == id) it.copy(visible = !it.visible) else it
        }
    }

    fun toggleLock(scene: Scene, id: String) {
        scene.layers = scene.layers.map {
            if (it.id == id) it.copy(locked = !it.locked) else it
        }
    }

    fun setOpacity(scene: Scene, id: String, opacity: Float) {
        scene.layers = scene.layers.map {
            if (it.id == id) it.copy(opacity = opacity.coerceIn(0f, 1f)) else it
        }
    }

    fun setAppearance(scene: Scene, id: String, transform: (com.draftstudio.app.model.Appearance) -> com.draftstudio.app.model.Appearance) {
        scene.layers = scene.layers.map {
            if (it.id == id) it.copy(appearance = transform(it.appearance)) else it
        }
    }

    fun setText(scene: Scene, id: String, transform: (com.draftstudio.app.model.TextAppearance) -> com.draftstudio.app.model.TextAppearance) {
        scene.layers = scene.layers.map {
            if (it.id == id) it.copy(text = it.text?.let(transform)) else it
        }
    }

    /** Set a keyframe on [property] of [layerId] at [frame]. */
    fun setKeyframe(scene: Scene, layerId: String, property: TrackType, frame: Int, value: Float, ease: String = "linear") {
        scene.layers = scene.layers.map { layer ->
            if (layer.id != layerId) return@map layer
            val tracks = layer.tracks.toMutableList()
            var track = tracks.firstOrNull { it.property == property }
            if (track == null) {
                track = Track(id = "track_${System.currentTimeMillis()}_${property}", property = property)
                tracks.add(track)
            }
            val kfs = track.keyframes.toMutableList()
            val existing = kfs.indexOfFirst { it.frame == frame }
            if (existing >= 0) kfs[existing] = Keyframe(frame = frame, value = value, ease = ease)
            else kfs.add(Keyframe(frame = frame, value = value, ease = ease))
            track = track.copy(keyframes = kfs.sortedBy { it.frame })
            tracks[tracks.indexOfFirst { it.property == property }] = track
            layer.copy(tracks = tracks)
        }
    }

    fun removeKeyframe(scene: Scene, layerId: String, property: TrackType, frame: Int) {
        scene.layers = scene.layers.map { layer ->
            if (layer.id != layerId) return@map layer
            val tracks = layer.tracks.map { t ->
                if (t.property != property) t
                else t.copy(keyframes = t.keyframes.filterNot { it.frame == frame })
            }.filterNot { it.keyframes.isEmpty() }
            layer.copy(tracks = tracks)
        }
    }

    fun clearTrack(scene: Scene, layerId: String, property: TrackType) {
        scene.layers = scene.layers.map { layer ->
            if (layer.id != layerId) layer
            else layer.copy(tracks = layer.tracks.filterNot { it.property == property })
        }
    }

    /** Add a pre-baked animation preset to [layerId] at [startFrame]. */
    fun applyPreset(
        scene: Scene,
        layerId: String,
        preset: AnimationPreset,
        startFrame: Int,
        duration: Float,
    ) {
        val fps = 30
        val frames = (duration * fps).toInt().coerceAtLeast(1)
        scene.layers = scene.layers.map { layer ->
            if (layer.id != layerId) return@map layer
            var tracks = layer.tracks.toMutableList()
            for (kf in preset.keyframes) {
                var track = tracks.firstOrNull { it.property == kf.property }
                if (track == null) {
                    track = Track(id = "track_${System.currentTimeMillis()}_${kf.property}", property = kf.property)
                    tracks.add(track)
                }
                val kfs = track.keyframes.toMutableList()
                kfs.add(
                    Keyframe(
                        frame = startFrame + kf.frame,
                        value = kf.value,
                        ease = kf.ease,
                    )
                )
                val idx = tracks.indexOfFirst { it.property == kf.property }
                tracks[idx] = track.copy(keyframes = kfs.sortedBy { it.frame })
            }
            layer.copy(tracks = tracks)
        }
    }

    fun setCameraKeyframe(scene: Scene, frame: Int) {
        val kf = Keyframe(
            frame = frame,
            value = 0f,
            ease = "easeInOut",
        )
        // Camera movement is stored as x/y/zoom/rotation keyframes on the camera.
        val x = scene.camera.keyframes.filter { it.frame == frame }
        // keep simple: store marker keyframe so timeline can show camera key
        val existing = scene.camera.keyframes.toMutableList()
        if (existing.none { it.frame == frame }) existing.add(kf)
        scene.camera = scene.camera.copy(keyframes = existing.sortedBy { it.frame })
    }

    fun removeCameraKeyframe(scene: Scene, frame: Int) {
        scene.camera = scene.camera.copy(
            keyframes = scene.camera.keyframes.filterNot { it.frame == frame }
        )
    }

    fun renameLayer(scene: Scene, id: String, name: String) {
        scene.layers = scene.layers.map {
            if (it.id == id) it.copy(name = name) else it
        }
    }

    fun duplicateScene(project: com.draftstudio.app.model.Project, sceneId: String): com.draftstudio.app.model.Project {
        val idx = project.scenes.indexOfFirst { it.id == sceneId }
        if (idx < 0) return project
        val src = project.scenes[idx]
        val copy = src.copy(
            id = "scene_${System.currentTimeMillis()}",
            name = src.name + " copy",
            layers = src.layers.map { l ->
                l.copy(
                    id = "layer_${System.currentTimeMillis()}_${l.type}",
                    tracks = l.tracks.map { t -> t.copy(id = "track_${System.currentTimeMillis()}_${t.property}") },
                )
            },
        )
        val scenes = project.scenes.toMutableList()
        scenes.add(idx + 1, copy)
        return project.copy(scenes = scenes)
    }

    fun deleteScene(project: com.draftstudio.app.model.Project, sceneId: String): com.draftstudio.app.model.Project {
        if (project.scenes.size <= 1) return project
        return project.copy(scenes = project.scenes.filterNot { it.id == sceneId })
    }

    fun renameScene(project: com.draftstudio.app.model.Project, sceneId: String, name: String): com.draftstudio.app.model.Project {
        return project.copy(
            scenes = project.scenes.map { if (it.id == sceneId) it.copy(name = name) else it }
        )
    }
}

/** Procedural animation presets — positions are relative to layer origin. */
data class AnimationPreset(
    val name: String,
    val keyframes: List<PresetKeyframe>,
)

data class PresetKeyframe(
    val property: TrackType,
    val frame: Int,
    val value: Float,
    val ease: String = "easeInOut",
)

object Presets {
    val all: List<AnimationPreset> = listOf(
        AnimationPreset("Slide In From Left", listOf(
            PresetKeyframe(TrackType.X, 0, -1400f, "easeOut"),
            PresetKeyframe(TrackType.X, 30, 0f, "easeOut"),
        )),
        AnimationPreset("Slide In From Right", listOf(
            PresetKeyframe(TrackType.X, 0, 1400f, "easeOut"),
            PresetKeyframe(TrackType.X, 30, 0f, "easeOut"),
        )),
        AnimationPreset("Bounce In", listOf(
            PresetKeyframe(TrackType.X, 0, 0f),
            PresetKeyframe(TrackType.Y, 0, 0f, "hold"),
            PresetKeyframe(TrackType.SCALE_X, 0, 0.2f),
            PresetKeyframe(TrackType.SCALE_Y, 0, 0.2f),
            PresetKeyframe(TrackType.SCALE_X, 18, 1.15f, "easeOut"),
            PresetKeyframe(TrackType.SCALE_Y, 18, 1.15f, "easeOut"),
            PresetKeyframe(TrackType.SCALE_X, 30, 1f, "easeOut"),
            PresetKeyframe(TrackType.SCALE_Y, 30, 1f, "easeOut"),
        )),
        AnimationPreset("Walk Cycle", listOf(
            PresetKeyframe(TrackType.Y, 0, 0f),
            PresetKeyframe(TrackType.Y, 8, -24f, "easeInOut"),
            PresetKeyframe(TrackType.Y, 16, 0f, "easeInOut"),
            PresetKeyframe(TrackType.Y, 24, -24f, "easeInOut"),
            PresetKeyframe(TrackType.Y, 32, 0f, "easeInOut"),
            PresetKeyframe(TrackType.ROTATION, 0, 0f),
            PresetKeyframe(TrackType.ROTATION, 8, -6f, "easeInOut"),
            PresetKeyframe(TrackType.ROTATION, 16, 0f, "easeInOut"),
            PresetKeyframe(TrackType.ROTATION, 24, 6f, "easeInOut"),
            PresetKeyframe(TrackType.ROTATION, 32, 0f, "easeInOut"),
        )),
        AnimationPreset("Jump", listOf(
            PresetKeyframe(TrackType.Y, 0, 0f),
            PresetKeyframe(TrackType.Y, 10, -90f, "easeOut"),
            PresetKeyframe(TrackType.Y, 26, 0f, "easeIn"),
        )),
        AnimationPreset("Spin 360", listOf(
            PresetKeyframe(TrackType.ROTATION, 0, 0f, "linear"),
            PresetKeyframe(TrackType.ROTATION, 24, 360f, "linear"),
        )),
        AnimationPreset("Fade In", listOf(
            PresetKeyframe(TrackType.OPACITY, 0, 0f),
            PresetKeyframe(TrackType.OPACITY, 24, 1f, "easeOut"),
        )),
        AnimationPreset("Fade Out", listOf(
            PresetKeyframe(TrackType.OPACITY, 0, 1f),
            PresetKeyframe(TrackType.OPACITY, 24, 0f, "easeIn"),
        )),
        AnimationPreset("Pulse", listOf(
            PresetKeyframe(TrackType.SCALE_X, 0, 1f),
            PresetKeyframe(TrackType.SCALE_Y, 0, 1f),
            PresetKeyframe(TrackType.SCALE_X, 15, 1.12f, "easeInOut"),
            PresetKeyframe(TrackType.SCALE_Y, 15, 1.12f, "easeInOut"),
            PresetKeyframe(TrackType.SCALE_X, 30, 1f, "easeInOut"),
            PresetKeyframe(TrackType.SCALE_Y, 30, 1f, "easeInOut"),
        )),
        AnimationPreset("Shake", listOf(
            PresetKeyframe(TrackType.X, 0, 0f),
            PresetKeyframe(TrackType.X, 2, -14f, "hold"),
            PresetKeyframe(TrackType.X, 4, 12f, "hold"),
            PresetKeyframe(TrackType.X, 6, -10f, "hold"),
            PresetKeyframe(TrackType.X, 8, 8f, "hold"),
            PresetKeyframe(TrackType.X, 10, -6f, "hold"),
            PresetKeyframe(TrackType.X, 12, 0f, "hold"),
        )),
        AnimationPreset("Pop In", listOf(
            PresetKeyframe(TrackType.SCALE_X, 0, 0f),
            PresetKeyframe(TrackType.SCALE_Y, 0, 0f),
            PresetKeyframe(TrackType.SCALE_X, 6, 1.3f, "easeOut"),
            PresetKeyframe(TrackType.SCALE_Y, 6, 1.3f, "easeOut"),
            PresetKeyframe(TrackType.SCALE_X, 12, 1f, "easeOut"),
            PresetKeyframe(TrackType.SCALE_Y, 12, 1f, "easeOut"),
        )),
        AnimationPreset("Idle Breathing", listOf(
            PresetKeyframe(TrackType.SCALE_X, 0, 1f),
            PresetKeyframe(TrackType.SCALE_Y, 0, 1f),
            PresetKeyframe(TrackType.SCALE_X, 20, 1.03f, "easeInOut"),
            PresetKeyframe(TrackType.SCALE_Y, 20, 1.03f, "easeInOut"),
            PresetKeyframe(TrackType.SCALE_X, 40, 1f, "easeInOut"),
            PresetKeyframe(TrackType.SCALE_Y, 40, 1f, "easeInOut"),
        )),
    )

    fun byName(name: String): AnimationPreset? = all.firstOrNull { it.name == name }
}
