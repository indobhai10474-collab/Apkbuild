package com.draftstudio.app.ai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.draftstudio.app.core.ProjectStore
import com.draftstudio.app.core.VoiceClip
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * On-device AI voiceover engine.
 *
 * Uses Android's built-in TextToSpeech (no network, no subscription).
 * The synthesized speech is converted to 16-bit mono PCM so it can be
 * mixed into exports and analyzed for lip-sync.
 *
 * Lip-sync works by envelope detection on the PCM: frames with louder
 * speech open the character's mouth (LIP track), silent frames close it.
 */
class TtsEngine(context: Context) {

    private val appContext: Context = context.applicationContext
    private val tts: TextToSpeech
    private val ready = AtomicBoolean(false)
    private var isError = false

    private val pendingListeners = ConcurrentHashMap<String, (Int) -> Unit>()
    private val mainHandler = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val res = tts.setLanguage(Locale.ENGLISH)
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.getDefault())
                }
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        val cb = utteranceId?.let { pendingListeners.remove(it) }
                        cb?.invoke(TextToSpeech.SUCCESS)
                    }
                    override fun onError(utteranceId: String?) {
                        val cb = utteranceId?.let { pendingListeners.remove(it) }
                        cb?.invoke(TextToSpeech.ERROR)
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?, errorCode: Int) {
                        val cb = utteranceId?.let { pendingListeners.remove(it) }
                        cb?.invoke(errorCode)
                    }
                })
                ready.set(true)
            } else {
                isError = true
            }
        }
    }

    fun isReady(): Boolean = ready.get()
    fun isError(): Boolean = isError

    fun languages(): List<Locale> {
        val list = tts.voices?.map { it.locale }?.distinctBy { it.language } ?: emptyList()
        return list.ifEmpty { listOf(Locale.ENGLISH, Locale.getDefault()) }
    }

    /**
     * Synthesize [text] to a [VoiceClip] stored in app storage.
     * Returns null on failure.
     */
    fun synthesize(
        text: String,
        rate: Float = 1.0f,
        pitch: Float = 1.0f,
        onDone: (VoiceClip?) -> Unit,
    ) {
        if (!ready.get()) {
            onDone(null)
            return
        }
        val fileName = "voice_${System.currentTimeMillis()}.pcm"
        val tempFile = File(ProjectStore.voiceDir(appContext), fileName)

        tts.setSpeechRate(rate)
        tts.setPitch(pitch)
        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, fileName)
        pendingListeners[fileName] = { status ->
            mainHandler.post {
                if (status == TextToSpeech.SUCCESS && tempFile.exists() && tempFile.length() > 44) {
                    val pcm = wavToPcm(tempFile)
                    if (pcm != null) {
                        val clip = VoiceClip(
                            id = "vc_${System.currentTimeMillis()}",
                            text = text,
                            fileName = fileName,
                            durationSeconds = pcm.size / 2f / 44100f,
                        )
                        ProjectStore.saveVoice(appContext, clip, pcm)
                        tempFile.delete()
                        onDone(clip)
                    } else {
                        tempFile.delete()
                        onDone(null)
                    }
                } else {
                    tempFile.delete()
                    onDone(null)
                }
            }
        }
        val result = tts.synthesizeToFile(text, params, tempFile, fileName)
        if (result != TextToSpeech.SUCCESS) {
            pendingListeners.remove(fileName)
            tempFile.delete()
            onDone(null)
        }
    }

    fun shutdown() {
        tts.shutdown()
    }

    // ==================== PCM utilities ====================

    /** Strip WAV header → raw little-endian 16-bit PCM. */
    private fun wavToPcm(file: File): ByteArray? {
        try {
            val raf = RandomAccessFile(file, "r")
            val data = ByteArray(raf.length().toInt())
            raf.readFully(data)
            raf.close()
            // find "data" chunk
            var offset = 12
            while (offset < data.size - 8) {
                val id = String(data, offset, 4, Charsets.US_ASCII)
                val size = leInt(data, offset + 4)
                if (id == "data") {
                    val start = offset + 8
                    val len = min(size, data.size - start)
                    val pcm = ByteArray(len)
                    System.arraycopy(data, start, pcm, 0, len)
                    return pcm
                }
                offset += 8 + size + (size and 1)
            }
            return null
        } catch (t: Throwable) { return null }
    }

    private fun leInt(data: ByteArray, at: Int): Int {
        return (data[at].toInt() and 0xFF) or
                ((data[at + 1].toInt() and 0xFF) shl 8) or
                ((data[at + 2].toInt() and 0xFF) shl 16) or
                ((data[at + 3].toInt() and 0xFF) shl 24)
    }

    /** Play a clip through the speaker. */
    fun play(root: java.io.File, clip: VoiceClip) {
        val pcm = ProjectStore.loadVoice(root, clip) ?: return
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(44100)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(pcm, 0, pcm.size)
        track.play()
    }
}

/**
 * Lip-sync analyzer: computes mouth-open envelope from speech PCM.
 * The result is a list of (timeSeconds, openness) samples that the editor
 * can bake into a LIP track as keyframes (2 samples per frame at 30fps).
 */
object LipSync {

    data class Sample(val timeSeconds: Float, val openness: Float)

    /** Analyze raw PCM (44100 Hz mono 16-bit). Returns one sample per 1/30s. */
    fun analyze(pcm: ByteArray, fps: Int = 30): List<Sample> {
        if (pcm.size < 2) return emptyList()
        val samplesPerSecond = 44100
        val window = samplesPerSecond / fps
        val total = pcm.size / 2
        val out = ArrayList<Sample>()
        var i = 0
        while (i < total) {
            var peak = 0f
            val end = min(i + window, total)
            var j = i
            while (j < end) {
                val v = shortAt(pcm, j) / 32768f
                peak = max(peak, abs(v))
                j++
            }
            val openness = (peak * 2.2f).coerceIn(0f, 1f)
            out.add(Sample(i / samplesPerSecond.toFloat(), openness))
            i = end
        }
        return out
    }

    /** Convert samples to keyframes on a character layer at a start frame. */
    fun bakeKeyframes(
        samples: List<Sample>,
        startFrame: Int,
        fps: Int = 30,
    ): List<com.draftstudio.app.model.Keyframe> {
        val out = ArrayList<com.draftstudio.app.model.Keyframe>()
        var lastOpen = -1f
        for (s in samples) {
            val frame = startFrame + (s.timeSeconds * fps).toInt()
            if (abs(s.openness - lastOpen) < 0.15f) continue
            out.add(com.draftstudio.app.model.Keyframe(frame, s.openness, "hold"))
            lastOpen = s.openness
        }
        return out
    }
}

/** WAV writer for mixing TTS audio into exports. */
object WavWriter {
    fun write(pcm: ByteArray, out: java.io.OutputStream, sampleRate: Int = 44100) {
        val dataSize = pcm.size
        val header = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray())
        header.putInt(36 + dataSize)
        header.put("WAVE".toByteArray())
        header.put("fmt ".toByteArray())
        header.putInt(16)
        header.putShort(1) // PCM
        header.putShort(1) // mono
        header.putInt(sampleRate)
        header.putInt(sampleRate * 2)
        header.putShort(2) // block align
        header.putShort(16) // bits
        header.put("data".toByteArray())
        header.putInt(dataSize)
        out.write(header.array())
        out.write(pcm)
    }
}

private fun shortAt(pcm: ByteArray, i: Int): Int {
    val b0 = pcm[i * 2].toInt() and 0xFF
    val b1 = pcm[i * 2 + 1].toInt() and 0xFF
    return (b0 or (b1 shl 8)).toShort().toInt()
}
