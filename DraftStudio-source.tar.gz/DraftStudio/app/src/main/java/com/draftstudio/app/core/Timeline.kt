package com.draftstudio.app.core

import com.draftstudio.app.model.Appearance
import com.draftstudio.app.model.Camera
import com.draftstudio.app.model.Layer
import com.draftstudio.app.model.LayerType
import com.draftstudio.app.model.Scene
import kotlin.math.cos
import kotlin.math.sin
/** Evaluates all animation tracks to a concrete render state for one frame. */
data class FrameState(
    val x: Float,
    val y: Float,
    val scaleX: Float,
    val scaleY: Float,
    val rotation: Float,
    val opacity: Float,
    val lipOpen: Float,
)

object Timeline {
    /** Render state of [layer] at [frame]. Values are in scene units (1280x720). */
    fun evaluate(layer: Layer, frame: Float): FrameState {
        return FrameState(
            x = Tracks.valueAt(layer, TrackType.X, frame, layer.x),
            y = Tracks.valueAt(layer, TrackType.Y, frame, layer.y),
            scaleX = Tracks.valueAt(layer, TrackType.SCALE_X, frame, layer.scaleX),
            scaleY = Tracks.valueAt(layer, TrackType.SCALE_Y, frame, layer.scaleY),
            rotation = Tracks.valueAt(layer, TrackType.ROTATION, frame, layer.rotation),
            opacity = Tracks.valueAt(layer, TrackType.OPACITY, frame, layer.opacity),
            lipOpen = Tracks.valueAt(layer, TrackType.LIP, frame, layer.appearance.lipOpen),
        )
    }

    /** Camera view at [frame] given project dimensions. */
    fun cameraView(scene: Scene, frame: Float): CameraView {
        val cam = scene.camera
        val cx = Tracks.valueAtForCamera(cam, frame, cam.x)
        val cy = Tracks.valueAtForCamera(cam, frame, cam.y)
        val cz = Tracks.valueAtForCamera(cam, frame, cam.zoom)
        val cr = Tracks.valueAtForCamera(cam, frame, cam.rotation)
        return CameraView(cx, cy, cz, cr)
    }

    fun totalFrames(scene: Scene): Int = scene.durationFrames

    /** Frame range covered by any keyframe in the scene. */
    fun usedRange(scene: Scene): Pair<Int, Int> {
        var min = Int.MAX_VALUE
        var max = Int.MIN_VALUE
        fun consider(f: Int) {
            if (f < min) min = f
            if (f > max) max = f
        }
        for (l in scene.layers) for (t in l.tracks) for (k in t.keyframes) consider(k.frame)
        for (k in scene.camera.keyframes) consider(k.frame)
        if (min == Int.MAX_VALUE) return 0 to totalFrames(scene)
        return min to max
    }
}

enum class CameraTrack { X, Y, ZOOM, ROTATION }

/** Camera viewport state at a frame. */
data class CameraView(
    val x: Float,
    val y: Float,
    val zoom: Float,
    val rotation: Float,
)

/** Procedural pseudo-random helpers (deterministic per seed). */
object Noise {
    fun hash(seed: Int, x: Int, y: Int): Float {
        var h = seed * 374761393 + x * 668265263 + y * 2246822519
        h = (h xor (h shr 13)) * 1274126177
        h = h xor (h shr 16)
        return ((h and 0x7fffffff) % 10000) / 10000f
    }

    fun hash01(seed: Int, i: Int): Float = hash(seed, i, i * 31)

    fun rand(seed: Int, i: Int, min: Float, max: Float): Float = min + (max - min) * hash01(seed, i)

    /** Simple value noise in [0,1] */
    fun value(seed: Int, x: Float, y: Float): Float {
        val xi = x.toInt()
        val yi = y.toInt()
        val fx = x - xi
        val fy = y - yi
        fun smooth(t: Float): Float = t * t * (3f - 2f * t)
        val a = hash(seed, xi, yi)
        val b = hash(seed, xi + 1, yi)
        val c = hash(seed, xi, yi + 1)
        val d = hash(seed, xi + 1, yi + 1)
        val u = smooth(fx)
        val v = smooth(fy)
        return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v
    }

    /** Fractal brownian motion in [0,1] */
    fun fbm(seed: Int, x: Float, y: Float, octaves: Int = 4): Float {
        var v = 0f
        var amp = 0.5f
        var freq = 1f
        var total = 0f
        for (i in 0 until octaves) {
            v += amp * value(seed + i * 17, x * freq, y * freq)
            total += amp
            amp *= 0.5f
            freq *= 2f
        }
        return v / total
    }
}

/** Deterministic rotation helpers for limbs. */
object Swing {
    fun sin(phase: Float, amp: Float): Float = sin(phase) * amp
    fun cos(phase: Float, amp: Float): Float = cos(phase) * amp
}
