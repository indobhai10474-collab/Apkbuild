package com.draftstudio.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DraftScheme = darkColorScheme(
    primary = Color(0xFFB388FF),
    onPrimary = Color(0xFF201A30),
    secondary = Color(0xFFFFD54F),
    onSecondary = Color(0xFF201A30),
    background = Color(0xFF12101E),
    onBackground = Color(0xFFE8E6F2),
    surface = Color(0xFF1C1930),
    onSurface = Color(0xFFE8E6F2),
    surfaceVariant = Color(0xFF2A2547),
    onSurfaceVariant = Color(0xFFC9C4E8),
    error = Color(0xFFFF8A80),
)

@Composable
fun DraftStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DraftScheme,
        content = content,
    )
}
