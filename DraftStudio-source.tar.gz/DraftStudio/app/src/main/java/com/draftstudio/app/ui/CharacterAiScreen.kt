package com.draftstudio.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.draftstudio.app.model.Appearance

/**
 * On-device AI character generator.
 * Instead of calling a paid cloud API, it procedurally composes a unique
 * character (deterministic per seed) with color/style/emotion/pose options.
 * Fully offline, instant, unlimited.
 */
@Composable
fun CharacterAiScreen(onDone: (Appearance, String) -> Unit, onBack: () -> Unit) {
    var style by remember { mutableStateOf("character") }
    var emotion by remember { mutableStateOf("neutral") }
    var prop by remember { mutableStateOf("none") }
    var color by remember { mutableStateOf(0xFF42A5F5L) }
    var accent by remember { mutableStateOf(0xFFEF5350L) }
    var skin by remember { mutableStateOf(0xFFFFCCB0L) }
    var seed by remember { mutableStateOf((Math.random() * 100000).toInt()) }
    var name by remember { mutableStateOf("My Character") }

    Scaffold(
        topBar = {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "back") }
                Text("AI Character Generator", style = MaterialTheme.typography.titleMedium)
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner).padding(16.dp).verticalScroll(rememberScrollState())) {
            // live preview
            CharacterPreview(style = style, emotion = emotion, prop = prop, color = color, accent = accent, skin = skin, seed = seed)
            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Style", Modifier.align(Alignment.CenterVertically))
                Spacer(Modifier.width(8.dp))
                listOf("character", "robot", "monster", "ghost").forEach { s ->
                    TextButton(onClick = { style = s }) {
                        Text(s, color = if (style == s) MaterialTheme.colorScheme.primary else Color.Gray)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Emotion", Modifier.align(Alignment.CenterVertically))
                Spacer(Modifier.width(8.dp))
                listOf("neutral", "happy", "sad", "angry", "surprised", "sleepy").forEach { e ->
                    TextButton(onClick = { emotion = e }) {
                        Text(e, color = if (emotion == e) MaterialTheme.colorScheme.primary else Color.Gray)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Prop", Modifier.align(Alignment.CenterVertically))
                Spacer(Modifier.width(8.dp))
                listOf("none", "hat", "glasses", "crown", "mic", "sword").forEach { p ->
                    TextButton(onClick = { prop = p }) {
                        Text(p, color = if (prop == p) MaterialTheme.colorScheme.primary else Color.Gray)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Body color", style = MaterialTheme.typography.bodySmall)
            Row {
                listOf(0xFF42A5F5L, 0xFFEF5350L, 0xFF66BB6AL, 0xFFFFA726L, 0xFFAB47BCL, 0xFF78909CL).forEach { c ->
                    Box(Modifier.size(28.dp).padding(4.dp).background(Color(c)).clickable { color = c })
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Accent (pants/hair)", style = MaterialTheme.typography.bodySmall)
            Row {
                listOf(0xFFEF5350L, 0xFF263238L, 0xFF37474FL, 0xFF455A64L, 0xFF1A237EL, 0xFF8D6E63L).forEach { c ->
                    Box(Modifier.size(28.dp).padding(4.dp).background(Color(c)).clickable { accent = c })
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Skin", style = MaterialTheme.typography.bodySmall)
            Row {
                listOf(0xFFFFCCB0L, 0xFF8D6E63L, 0xFFFFE0B2L, 0xFF5D4037L, 0xFFFF8A80L).forEach { c ->
                    Box(Modifier.size(28.dp).padding(4.dp).background(Color(c)).clickable { skin = c })
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Character name") },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val appearance = Appearance(
                        character = true,
                        color = color,
                        accent = accent,
                        skin = skin,
                        seed = seed,
                        style = style,
                        emotion = emotion,
                        prop = prop,
                    )
                    onDone(appearance, name)
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Add to Scene") }
            TextButton(onClick = { seed = (Math.random() * 100000).toInt() }) { Text("🎲 Randomize look") }
        }
    }
}

@Composable
fun CharacterPreview(style: String, emotion: String, prop: String, color: Long, accent: Long, skin: Long, seed: Int) {
    val bmp = remember(style, emotion, prop, color, accent, skin, seed) {
        val b = android.graphics.Bitmap.createBitmap(220, 380, android.graphics.Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(b)
        val layer = com.draftstudio.app.model.Layer(
            id = "preview",
            name = "preview",
            type = com.draftstudio.app.model.LayerType.CHARACTER,
            appearance = Appearance(
                character = true,
                color = color,
                accent = accent,
                skin = skin,
                seed = seed,
                style = style,
                emotion = emotion,
                prop = prop,
            ),
        )
        com.draftstudio.app.render.SceneRenderer.drawCharacter(c, layer, com.draftstudio.app.core.FrameState(0f, 0f, 1f, 1f, 0f, 1f, 0.2f), 0f)
        b.asImageBitmap()
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
            .background(Color(0xFF0A0914)),
        contentAlignment = Alignment.Center,
    ) {
        Image(bmp, contentDescription = null, modifier = Modifier.height(280.dp))
    }
}
