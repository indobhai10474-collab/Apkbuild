package com.draftstudio.app.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.draftstudio.app.core.Timeline
import com.draftstudio.app.model.Project
import com.draftstudio.app.render.SceneRenderer
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer

object Exporter {

    fun widthOf(p: Project): Int = p.width
    fun heightOf(p: Project): Int = p.height
    fun fpsOf(p: Project): Int = p.fps

    fun renderFrame(project: Project, sceneIndex: Int, frame: Int, out: Bitmap) {
        val scene = project.scenes[sceneIndex]
        val canvas = Canvas(out)
        canvas.drawColor(Color.WHITE)
        SceneRenderer.render(
            canvas, scene, frame.toFloat(),
            project.width.toFloat(), project.height.toFloat()
        )
    }

    /** Renders a PNG frame sequence into [outDir]. Returns count. */
    fun exportPngSequence(
        project: Project,
        sceneIndex: Int,
        outDir: File,
        onProgress: (Int, Int) -> Unit,
    ): Int {
        val scene = project.scenes[sceneIndex]
        val total = Timeline.totalFrames(scene)
        outDir.mkdirs()
        val bitmap = Bitmap.createBitmap(project.width, project.height, Bitmap.Config.ARGB_8888)
        for (f in 0 until total) {
            renderFrame(project, sceneIndex, f, bitmap)
            val file = File(outDir, "frame_%04d.png".format(f))
            FileOutputStream(file).use { it ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            onProgress(f + 1, total)
        }
        bitmap.recycle()
        return total
    }

    // ==================== GIF ====================

    /** Exports an animated GIF (pure Kotlin, works on every Android version). */
    fun exportGif(
        project: Project,
        sceneIndex: Int,
        out: OutputStream,
        onProgress: (Int, Int) -> Unit,
    ): Int {
        val scene = project.scenes[sceneIndex]
        val total = Timeline.totalFrames(scene)
        val w = project.width
        val h = project.height
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val frames = ArrayList<Bitmap>(total)
        for (f in 0 until total) {
            renderFrame(project, sceneIndex, f, bitmap)
            // quantize to 256 colors per frame (keep simple, per-frame local palette)
            frames.add(quantize(bitmap))
            onProgress(f + 1, total)
        }
        bitmap.recycle()
        GifEncoder.write(out, frames, w, h, fpsOf(project))
        frames.forEach { it.recycle() }
        return total
    }

    /** Simple 256-color quantization via uniform 3-3-2 RGB mapping. */
    private fun quantize(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val palette = HashMap<Int, Int>() // rgb key -> index
        var next = 0
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val c = pixels[i]
            val key = ((c and 0xFF) shr 6) shl 6 or (((c shr 8) and 0xFF) shr 6) shl 3 or (((c shr 16) and 0xFF) shr 6)
            var idx = palette[key]
            if (idx == null) {
                idx = next++
                palette[key] = idx
            }
            out.setPixel(i % w, i / w, colorFromKey(key))
        }
        return out
    }

    private fun colorFromKey(key: Int): Int {
        val b = ((key shr 6) and 0x3) * 85
        val g = ((key shr 3) and 0x7) * 36
        val r = (key and 0x7) * 36
        return Color.rgb(r, g, b)
    }
}

/**
 * Minimal GIF89a encoder: LZW compression with per-frame local color tables.
 * Frames must be 8-bit indexed (see quantize). This keeps the APK dependency-free.
 */
object GifEncoder {

    fun write(out: OutputStream, frames: List<Bitmap>, w: Int, h: Int, fps: Int) {
        val delay = (1000f / fps).toInt().coerceAtLeast(1)
        val bytes = ByteArrayOutputStreamEx(out)
        bytes.writeAscii("GIF89a")
        writeLSD(bytes, w, h)
        for ((i, frame) in frames.withIndex()) {
            // build color table from frame
            val palette = buildPalette(frame)
            writeGCE(bytes, delay, 0)
            writeImageDescriptor(bytes, w, h, palette.size)
            writeTable(bytes, palette)
            writeLZW(bytes, frame, w, h)
            if (i == frames.size - 1) {
                bytes.write(0x3B) // trailer
            }
        }
        bytes.flush()
    }

    private fun writeLSD(out: ByteArrayOutputStreamEx, w: Int, h: Int) {
        out.writeLe16(w)
        out.writeLe16(h)
        out.write(0x00) // no global table
        out.write(0x00) // background color
        out.write(0x00) // pixel aspect
    }

    private fun writeGCE(out: ByteArrayOutputStreamEx, delay: Int, transparent: Int) {
        out.write(0x21)
        out.write(0xF9)
        out.write(0x04)
        out.write(0x04) // disposal = leave in place
        out.writeLe16(delay)
        out.write(transparent)
        out.write(0x00)
    }

    private fun writeImageDescriptor(out: ByteArrayOutputStreamEx, w: Int, h: Int, paletteSize: Int) {
        out.write(0x2C)
        out.writeLe16(0) // left
        out.writeLe16(0) // top
        out.writeLe16(w)
        out.writeLe16(h)
        val bits = Integer.numberOfTrailingZeros(paletteSize) // power of two → log2
        val packed = 0x80 or ((bits - 1) shl 4) // local table, size bits
        out.write(packed)
    }

    private fun buildPalette(frame: Bitmap): IntArray {
        val set = LinkedHashSet<Int>()
        val w = frame.width
        val h = frame.height
        val pixels = IntArray(w * h)
        frame.getPixels(pixels, 0, w, 0, 0, w, h)
        for (c in pixels) set.add(c and 0xFFFFFF)
        val list = set.toMutableList()
        // pad to power of two
        var size = 1
        while (size < list.size) size *= 2
        while (list.size < size) list.add(0x000000)
        return list.toIntArray()
    }

    private fun writeTable(out: ByteArrayOutputStreamEx, palette: IntArray) {
        for (c in palette) {
            out.write((c shr 16) and 0xFF)
            out.write((c shr 8) and 0xFF)
            out.write(c and 0xFF)
        }
    }

    private fun writeLZW(out: ByteArrayOutputStreamEx, frame: Bitmap, w: Int, h: Int) {
        // build color -> index map consistent with the palette
        val palette = buildPalette(frame)
        val indexMap = HashMap<Int, Int>()
        for ((i, c) in palette.withIndex()) indexMap[c] = i
        val pixels = IntArray(w * h)
        frame.getPixels(pixels, 0, w, 0, 0, w, h)
        val indices = IntArray(pixels.size)
        for (i in pixels.indices) {
            val key = pixels[i] and 0xFFFFFF
            indices[i] = indexMap[key] ?: 0
        }
        // minimum code size from palette size (256 colors → 8)
        val minCode = 8
        val enc = LzwEncoder(indices, minCode)
        val data = enc.encode()
        // sub-blocks of up to 255 bytes
        out.write(minCode)
        var i = 0
        while (i < data.size) {
            val n = minOf(255, data.size - i)
            out.write(n)
            out.write(data, i, n)
            i += n
        }
        out.write(0x00) // block terminator
    }
}

/** ByteArrayOutputStream that also writes little-endian and ascii helpers. */
private class ByteArrayOutputStreamEx(private val delegate: OutputStream) {
    private val buf = ByteArray(4)
    fun writeLe16(v: Int) {
        buf[0] = (v and 0xFF).toByte()
        buf[1] = ((v shr 8) and 0xFF).toByte()
        delegate.write(buf, 0, 2)
    }
    fun write(b: Int) { delegate.write(b) }
    fun write(b: ByteArray, off: Int, len: Int) { delegate.write(b, off, len) }
    fun writeAscii(s: String) { delegate.write(s.toByteArray()) }
    fun flush() { delegate.flush() }
}

/**
 * Minimal GIF LZW encoder. Produces the same output style as classic encoders
 * (clear code + EOI, growing code width).
 */
class LzwEncoder(private val indices: IntArray, private val minCodeSize: Int) {

    fun encode(): ByteArray {
        val out = ByteArrayOutputStream()
        val clearCode = 1 shl minCodeSize
        val eoiCode = clearCode + 1
        var codeSize = minCodeSize + 1
        var nextCode = eoiCode + 1
        val dict = HashMap<Long, Int>()
        fun resetDict() {
            dict.clear()
            nextCode = eoiCode + 1
            codeSize = minCodeSize + 1
            for (i in 0 until (1 shl minCodeSize)) dict.put(i.toLong(), i)
        }
        resetDict()
        out.writeBits(clearCode, codeSize)
        if (indices.isEmpty()) {
            out.writeBits(eoiCode, codeSize)
            return out.toByteArray()
        }
        var current = indices[0].toLong()
        for (i in 1 until indices.size) {
            val k = indices[i].toLong()
            val combined = (current shl 8) or k
            if (dict.containsKey(combined)) {
                current = combined
            } else {
                out.writeBits(dict[current]!!, codeSize)
                dict[combined] = nextCode++
                if (nextCode > (1 shl codeSize) && codeSize < 12) {
                    codeSize++
                }
                if (nextCode >= 4096) {
                    out.writeBits(clearCode, codeSize)
                    resetDict()
                }
                current = k
            }
        }
        out.writeBits(dict[current]!!, codeSize)
        out.writeBits(eoiCode, codeSize)
        return out.toByteArray()
    }
}

/** Bit writer that packs LSB-first into bytes. */
class ByteArrayOutputStream {
    private val data = ArrayList<Byte>(512)
    private var bitBuf = 0
    private var bitCount = 0

    fun writeBits(value: Int, n: Int) {
        for (i in 0 until n) {
            bitBuf = bitBuf or (((value shr i) and 1) shl bitCount)
            bitCount++
            if (bitCount == 8) {
                data.add(bitBuf.toByte())
                bitBuf = 0
                bitCount = 0
            }
        }
    }

    fun toByteArray(): ByteArray {
        if (bitCount > 0) {
            data.add(bitBuf.toByte())
            bitBuf = 0
            bitCount = 0
        }
        return data.toByteArray()
    }
}

// ==================== MP4 (MediaCodec) ====================

object Mp4Exporter {

    /**
     * Renders the scene to an H.264 MP4 using MediaCodec + MediaMuxer.
     * Works fully offline. 1280x720 is a safe size for any device.
     */
    fun export(
        project: Project,
        sceneIndex: Int,
        dest: File,
        onProgress: (Int, Int) -> Unit,
    ): Boolean {
        val scene = project.scenes[sceneIndex]
        val w = project.width
        val h = project.height
        val fps = project.fps.coerceIn(10, 60)
        val total = Timeline.totalFrames(scene)
        val bitrate = 6_000_000

        // choose codec
        val codecName = findEncoder("video/avc")
            ?: return false
        val format = MediaFormat.createVideoFormat("video/avc", w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }

        val codec = MediaCodec.createByCodecName(codecName)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        val muxer = MediaMuxer(dest.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var trackIndex = -1
        var muxerStarted = false
        var pts = 0L
        val frameDurationUs = 1_000_000L / fps

        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

        // ByteBuffers for YUV
        val yuvBuffer = ByteBuffer.allocateDirect(w * h * 3 / 2)

        try {
            for (f in 0 until total) {
                renderFrameToBitmap(project, sceneIndex, f, bitmap)
                val inputIndex = codec.dequeueInputBuffer(10_000)
                if (inputIndex >= 0) {
                    val inputBuffer = codec.getInputBuffer(inputIndex)
                    yuvBuffer.clear()
                    argbToYuv420(bitmap, w, h, yuvBuffer)
                    yuvBuffer.position(0)
                    if (inputBuffer != null) {
                        inputBuffer.clear()
                        inputBuffer.put(yuvBuffer)
                        codec.queueInputBuffer(inputIndex, 0, yuvBuffer.capacity(), pts, 0)
                    }
                }
                pts += frameDurationUs

                // drain
                val info = MediaCodec.BufferInfo()
                while (true) {
                    val outIndex = codec.dequeueOutputBuffer(info, 0)
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!muxerStarted && trackIndex < 0) {
                            trackIndex = muxer.addTrack(codec.outputFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                    } else if (outIndex >= 0) {
                        val outBuf = codec.getOutputBuffer(outIndex)
                        if (outBuf != null) {
                            if (info.size > 0 && muxerStarted) {
                                outBuf.position(info.offset)
                                outBuf.limit(info.offset + info.size)
                                muxer.writeSampleData(trackIndex, outBuf, info)
                            }
                        }
                        codec.releaseOutputBuffer(outIndex, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                    } else if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        break
                    }
                }
                onProgress(f + 1, total)
            }
        } finally {
            try { codec.signalEndOfInputStream() } catch (t: Throwable) {}
            drainUntilEos(codec, muxer, trackIndex, muxerStarted)
            bitmap.recycle()
            if (muxerStarted) { try { muxer.stop() } catch (t: Throwable) {} }
            try { muxer.release() } catch (t: Throwable) {}
            try { codec.stop() } catch (t: Throwable) {}
            try { codec.release() } catch (t: Throwable) {}
        }
        return dest.exists() && dest.length() > 0
    }

    private fun drainUntilEos(codec: MediaCodec, muxer: MediaMuxer, trackIndex: Int, started: Boolean) {
        val info = MediaCodec.BufferInfo()
        var timeout = 0
        while (timeout < 60) {
            val outIndex = codec.dequeueOutputBuffer(info, 10_000)
            if (outIndex >= 0) {
                val outBuf = codec.getOutputBuffer(outIndex)
                if (outBuf != null && started && info.size > 0) {
                    outBuf.position(info.offset)
                    outBuf.limit(info.offset + info.size)
                    muxer.writeSampleData(trackIndex, outBuf, info)
                }
                codec.releaseOutputBuffer(outIndex, false)
            } else if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (timeout++ > 30) break
            } else break
        }
    }

    private fun renderFrameToBitmap(project: Project, sceneIndex: Int, frame: Int, bitmap: Bitmap) {
        val scene = project.scenes[sceneIndex]
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        SceneRenderer.render(
            canvas, scene, frame.toFloat(),
            project.width.toFloat(), project.height.toFloat()
        )
    }

    private fun argbToYuv420(bitmap: Bitmap, w: Int, h: Int, out: ByteBuffer) {
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        val ySize = w * h
        val uvSize = ySize / 4
        out.clear()
        val yuv = ByteArray(ySize + uvSize * 2)
        var yPos = 0
        var uPos = ySize
        var vPos = ySize + uvSize
        for (i in 0 until ySize) {
            val c = pixels[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
            yuv[yPos++] = y.toByte()
            val xi = i % w
            val yi = i / w
            if ((xi and 1) == 0 && (yi and 1) == 0) {
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                yuv[uPos++] = u.toByte()
                yuv[vPos++] = v.toByte()
            }
        }
        out.put(yuv)
        out.position(0)
    }

    private fun findEncoder(mime: String): String? {
        val codecs = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        for (c in codecs) {
            if (c.isEncoder) {
                for (t in c.supportedTypes) {
                    if (t.equals(mime, ignoreCase = true)) {
                        return c.name
                    }
                }
            }
        }
        return null
    }
}

/** MediaStore helpers to save exports to the gallery. */
object ExportSaver {

    fun saveToGallery(context: Context, file: File, mime: String, displayName: String): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/DraftStudio")
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val uri = resolver.insert(collection, values) ?: return null
        resolver.openOutputStream(uri)?.use { os ->
            file.inputStream().use { it.copyTo(os) }
        }
        return uri
    }
}
