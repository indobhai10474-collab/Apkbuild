package com.draftstudio.app.model

import kotlinx.serialization.Serializable

/**
 * DraftStudio project model.
 *
 * A project is a list of [Scene]s. Each scene holds [Layer]s (background,
 * characters, props, effects, audio) that are animated with [Keyframe]s on
 * tracks. Everything serializes to JSON so projects are portable and easy to
 * share.
 */

@Serializable
data class Project(
    val version: Int = 1,
    val id: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val width: Int = 1280,
    val height: Int = 720,
    val fps: Int = 30,
    val scenes: List<Scene> = listOf(Scene.default(width, height)),
) {
    val sceneCount: Int get() = scenes.size
}

@Serializable
data class Scene(
    val id: String,
    val name: String,
    var durationSeconds: Float = 10f,
    var layers: List<Layer> = emptyList(),
    var camera: Camera = Camera(),
    var background: SceneBackground = SceneBackground(),
) {
    val durationFrames: Int get() = (durationSeconds * 30f).toInt().coerceAtLeast(1)

    companion object {
        fun default(w: Int, h: Int): Scene = Scene(
            id = "scene_1",
            name = "Scene 1",
            durationSeconds = 10f,
            camera = Camera(width = w, height = h),
        )
    }
}

@Serializable
data class Camera(
    var x: Float = 0f,
    var y: Float = 0f,
    var zoom: Float = 1f,
    var rotation: Float = 0f,
    var width: Int = 1280,
    var height: Int = 720,
    var keyframes: List<Keyframe> = emptyList(),
)

@Serializable
data class SceneBackground(
    var type: String = "gradient", // gradient | solid | stars | mountains | none
    var colorTop: Long = 0xFFB3E5FC,
    var colorBottom: Long = 0xFF1A237E,
    var color: Long = 0xFFFFFFFF,
    var seed: Int = 7,
    var gradientAngle: Float = 0f,
)

enum class LayerType { BACKGROUND, CHARACTER, PROP, EFFECT, TEXT, AUDIO }

@Serializable
data class Layer(
    val id: String,
    var name: String,
    var type: LayerType,
    var visible: Boolean = true,
    var locked: Boolean = false,
    var opacity: Float = 1f,
    // Character / prop appearance descriptor
    var appearance: Appearance = Appearance(),
    var text: TextAppearance? = null,
    // animation tracks
    var tracks: List<Track> = emptyList(),
    // properties animated implicitly by tracks
    var x: Float = 0f,
    var y: Float = 0f,
    var scaleX: Float = 1f,
    var scaleY: Float = 1f,
    var rotation: Float = 0f,
    var layerOrder: Int = 0,
) {
    val hasAudio: Boolean get() = type == LayerType.AUDIO
}

@Serializable
data class Appearance(
    var character: Boolean = true,
    var color: Long = 0xFF42A5F5,
    var accent: Long = 0xFFEF5350,
    var skin: Long = 0xFFFFCCB0,
    var seed: Int = 11,
    var style: String = "character", // character | robot | monster | ghost
    var emotion: String = "neutral", // neutral | happy | sad | angry | surprised | sleepy
    var lipOpen: Float = 0f, // 0..1, driven by lip-sync track
    var eyeState: String = "open", // open | blink | closed
    var prop: String = "none", // none | hat | glasses | crown | mic | sword
)

@Serializable
data class TextAppearance(
    var content: String = "Hello!",
    var color: Long = 0xFFFFFFFF,
    var size: Float = 48f,
    var bold: Boolean = false,
    var align: String = "center", // center | left | right
)

enum class TrackType { X, Y, SCALE_X, SCALE_Y, ROTATION, OPACITY, LIP, EMOTION, LOOK_X, LOOK_Y }

@Serializable
data class Track(
    val id: String,
    var property: TrackType,
    var keyframes: List<Keyframe> = emptyList(),
) {
    fun sort() {
        keyframes = keyframes.sortedBy { it.frame }
    }
}

@Serializable
data class Keyframe(
    var frame: Int = 0,
    var value: Float = 0f,
    var ease: String = "linear", // linear | easeIn | easeOut | easeInOut | hold
)
