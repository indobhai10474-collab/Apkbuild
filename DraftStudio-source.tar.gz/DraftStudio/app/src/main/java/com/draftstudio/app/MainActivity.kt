package com.draftstudio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.draftstudio.app.ui.DraftStudioApp
import com.draftstudio.app.ui.theme.DraftStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DraftStudioTheme {
                DraftStudioApp()
            }
        }
    }
}
