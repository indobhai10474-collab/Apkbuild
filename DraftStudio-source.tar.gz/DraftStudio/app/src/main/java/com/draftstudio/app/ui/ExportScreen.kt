package com.draftstudio.app.ui

import android.os.Environment
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.draftstudio.app.export.Exporter
import com.draftstudio.app.export.Mp4Exporter
import com.draftstudio.app.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Export screen: MP4 (H.264 via MediaCodec), GIF, PNG sequence.
 * All offline, saved to Movies/DraftStudio.
 */
@Composable
fun ExportScreen(project: Project?, onBack: () -> Unit) {
    if (project == null) {
        Text("No project loaded.", Modifier.padding(24.dp))
        return
    }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var result by remember { mutableStateOf<String?>() }

    Scaffold(
        topBar = {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "back") }
                Text("Export — ${project.name}", style = MaterialTheme.typography.titleMedium)
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner).padding(16.dp)) {
            Text("Output: ${project.width}x${project.height} @ ${project.fps}fps", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Rendered with the same engine as the preview — fully offline.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))

            if (busy) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressIndicator()
                    Spacer(Modifier.padding(8.dp))
                    Text("Exporting… ${(progress * 100).toInt()}%")
                }
                Spacer(Modifier.height(16.dp))
            }

            result?.let {
                Text(it, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
            }

            Button(onClick = {
                if (busy) return@Button
                busy = true
                progress = 0f
                result = null
                scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                            ?: File(context.filesDir, "exports")
                        dir.mkdirs()
                        val dest = File(dir, "draft_${System.currentTimeMillis()}.mp4")
                        val r = Mp4Exporter.export(project, 0, dest) { done, total ->
                            progress = done.toFloat() / total
                        }
                        if (r) {
                            val uri = com.draftstudio.app.export.ExportSaver.saveToGallery(
                                context, dest, "video/mp4", dest.name
                            )
                            uri != null || dest.exists()
                        } else false
                    }
                    busy = false
                    result = if (ok) "✅ MP4 saved to Movies/DraftStudio" else "❌ Export failed (no H.264 encoder?)"
                }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text("Export MP4 (H.264)")
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                if (busy) return@Button
                busy = true
                progress = 0f
                result = null
                scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                            ?: File(context.filesDir, "exports")
                        dir.mkdirs()
                        val dest = File(dir, "draft_${System.currentTimeMillis()}.gif")
                        dest.outputStream().use { os ->
                            Exporter.exportGif(project, 0, os) { done, total ->
                                progress = done.toFloat() / total
                            }
                        }
                        val uri = com.draftstudio.app.export.ExportSaver.saveToGallery(
                            context, dest, "image/gif", dest.name
                        )
                        uri != null || dest.exists()
                    }
                    busy = false
                    result = if (ok) "✅ GIF saved to Movies/DraftStudio" else "❌ GIF export failed"
                }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text("Export GIF")
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                if (busy) return@Button
                busy = true
                progress = 0f
                result = null
                scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "draft_png")
                        dir.mkdirs()
                        Exporter.exportPngSequence(project, 0, dir) { done, total ->
                            progress = done.toFloat() / total
                        }
                        true
                    }
                    busy = false
                    result = if (ok) "✅ PNG frames in app Pictures/draft_png" else "❌ PNG export failed"
                }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text("Export PNG Sequence")
            }
            Spacer(Modifier.height(16.dp))
            Text("Tip: add a voiceover clip, then export MP4 — narration syncs with lip-sync.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
