package com.draftstudio.app.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Duplicate
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.draftstudio.app.core.Presets
import com.draftstudio.app.core.Timeline
import com.draftstudio.app.model.LayerType
import com.draftstudio.app.model.TrackType
import com.draftstudio.app.render.SceneRenderer

private enum class EditorTab { CANVAS, LAYERS, PROPERTIES, SCENES }

@Composable
fun EditorScreen(
    state: EditorState,
    onBack: () -> Unit,
    onCharacterAI: () -> Unit,
    onBackgroundAI: () -> Unit,
    onVoiceover: () -> Unit,
    onExport: () -> Unit,
) {
    var tab by remember { mutableStateOf(EditorTab.CANVAS) }

    // playback loop
    LaunchedEffect(state.playing) {
        if (state.playing) state.playLoop()
    }

    // render preview bitmap on frame change
    var preview by remember { mutableStateOf<ImageBitmap?>() }
    LaunchedEffect(state.currentFrame, state.scene.layers, state.scene.background, state.scene.camera) {
        val bmp = Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val s = 640f / 1280f // preview scale
        canvas.scale(s, s)
        SceneRenderer.render(
            canvas, state.scene, state.currentFrame,
            1280f, 720f
        )
        preview = bmp.asImageBitmap()
    }

    Scaffold { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            // top bar
            Surface(tonalElevation = 2.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    Text(state.project.name, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onCharacterAI) { Text("AI Character") }
                    TextButton(onClick = onBackgroundAI) { Text("AI Bg") }
                    TextButton(onClick = onVoiceover) { Text("Voice") }
                    TextButton(onClick = onExport) { Text("Export") }
                }
            }

            // main area
            Row(Modifier.weight(1f).fillMaxWidth()) {
                // left: preview canvas
                Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF0A0914))) {
                    preview?.let { img ->
                        ComposeCanvas(
                            modifier = Modifier
                                .padding(8.dp)
                                .aspectRatio(16f / 9f)
                                .pointerInput(Unit) {
                                    detectDragGestures { change, dragAmount ->
                                        // drag to move selected layer
                                        val id = state.selectedLayerId ?: return@detectDragGestures
                                        val scale = 1280f / 640f
                                        state.addOrMoveLayer(id, dragAmount.x * scale, dragAmount.y * scale)
                                    }
                                },
                            onDraw = { drawImage(img) }
                        )
                    } ?: Text("Loading preview...", color = Color.Gray, modifier = Modifier.padding(24.dp))
                }

                // right: panel
                Surface(Modifier.width(280.dp).fillMaxHeight(), color = MaterialTheme.colorScheme.surface) {
                    Column(Modifier.fillMaxSize()) {
                        TabRow(selectedTabIndex = tab.ordinal) {
                            EditorTab.entries.forEach { t ->
                                Tab(
                                    selected = tab == t,
                                    onClick = { tab = t },
                                    text = { Text(t.name.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 11.sp) }
                                )
                            }
                        }
                        when (tab) {
                            EditorTab.CANVAS -> CanvasPanel(state)
                            EditorTab.LAYERS -> LayersPanel(state, onAddCharacter = {
                                onCharacterAI()
                            }, onAddProp = {
                                state.addPropLayer()
                            }, onAddText = {
                                state.addTextLayer()
                            }, onAddEffect = {
                                state.addEffectLayer()
                            })
                            EditorTab.PROPERTIES -> PropertiesPanel(state)
                            EditorTab.SCENES -> ScenesPanel(state)
                        }
                    }
                }
            }

            // timeline
            TimelineBar(state)
        }
    }
}

/** Drag-move helper: sets x/y keyframes if the property has tracks, else static x/y. */
fun EditorState.addOrMoveLayer(id: String, dx: Float, dy: Float) {
    val layer = scene.layers.firstOrNull { it.id == id } ?: return
    if (layer.locked) return
    val hasX = layer.tracks.any { it.property == TrackType.X }
    val hasY = layer.tracks.any { it.property == TrackType.Y }
    val frame = currentFrame.toInt()
    if (hasX || hasY) {
        if (hasX) {
            val cur = com.draftstudio.app.core.Tracks.valueAt(layer, TrackType.X, currentFrame, layer.x)
            CommandsAccess.setKeyframe(scene, id, TrackType.X, frame, cur + dx)
        }
        if (hasY) {
            val cur = com.draftstudio.app.core.Tracks.valueAt(layer, TrackType.Y, currentFrame, layer.y)
            CommandsAccess.setKeyframe(scene, id, TrackType.Y, frame, cur + dy)
        }
    } else {
        scene.layers = scene.layers.map {
            if (it.id == id) it.copy(x = layer.x + dx, y = layer.y + dy) else it
        }
    }
    persist()
}

private object CommandsAccess {
    fun setKeyframe(scene: com.draftstudio.app.model.Scene, layerId: String, property: TrackType, frame: Int, value: Float) {
        com.draftstudio.app.core.Commands.setKeyframe(scene, layerId, property, frame, value)
    }
}

// ============ CANVAS PANEL ============

@Composable
private fun CanvasPanel(state: EditorState) {
    Column(Modifier.padding(12.dp)) {
        Text("Preview", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        Row {
            Text("Frame", style = MaterialTheme.typography.bodySmall)
            Text(" ${state.currentFrame.toInt()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.weight(1f))
            Text("of ${Timeline.totalFrames(state.scene)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(4.dp))
        Slider(
            value = state.currentFrame,
            onValueChange = { state.seek(it) },
            valueRange = 0f..Timeline.totalFrames(state.scene).toFloat(),
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                if (state.playing) state.stop()
                else {
                    state.playing = true
                }
            }) {
                Icon(if (state.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(4.dp))
                Text(if (state.playing) "Pause" else "Play")
            }
            TextButton(onClick = { state.setCameraKeyframe() }) { Text("Camera Key") }
        }
        Spacer(Modifier.height(8.dp))
        Text("Tip: drag on the canvas to move the selected layer.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ============ LAYERS PANEL ============

@Composable
private fun LayersPanel(state: EditorState, onAddCharacter: () -> Unit, onAddProp: () -> Unit, onAddText: () -> Unit, onAddEffect: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAddCharacter, modifier = Modifier.weight(1f)) { Text("+ Char") }
            Button(onClick = onAddProp, modifier = Modifier.weight(1f)) { Text("+ Prop") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAddText, modifier = Modifier.weight(1f)) { Text("+ Text") }
            Button(onClick = onAddEffect, modifier = Modifier.weight(1f)) { Text("+ FX") }
        }
        Spacer(Modifier.height(12.dp))
        Text("Layers", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        if (state.scene.layers.isEmpty()) {
            Text("No layers yet. Add a character, prop, text or effect.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(state.scene.layers, key = { it.id }) { layer ->
                    LayerRow(state, layer)
                }
            }
        }
    }
}

@Composable
private fun LayerRow(state: EditorState, layer: com.draftstudio.app.model.Layer) {
    val selected = state.selectedLayerId == layer.id
    Card(
        onClick = { state.selectLayer(layer.id) },
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { state.toggleVisible(layer.id) }, modifier = Modifier.size(32.dp)) {
                Icon(if (layer.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff, "visible", tint = if (layer.visible) Color.White else Color.Gray)
            }
            IconButton(onClick = { state.toggleLock(layer.id) }, modifier = Modifier.size(32.dp)) {
                Icon(if (layer.locked) Icons.Default.Lock else Icons.Default.LockOpen, "lock", tint = if (layer.locked) MaterialTheme.colorScheme.secondary else Color.Gray)
            }
            Column(Modifier.weight(1f)) {
                Text(layer.name, fontSize = 13.sp, color = if (selected) MaterialTheme.colorScheme.primary else Color.White)
                Text(layer.type.name, fontSize = 10.sp, color = Color.Gray)
            }
            IconButton(onClick = { state.moveLayer(layer.id, -1) }, modifier = Modifier.size(28.dp)) { Text("↑", fontSize = 12.sp) }
            IconButton(onClick = { state.moveLayer(layer.id, 1) }, modifier = Modifier.size(28.dp)) { Text("↓", fontSize = 12.sp) }
            IconButton(onClick = { state.duplicateLayer(layer.id) }, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.Duplicate, "dup", Modifier.size(16.dp)) }
            IconButton(onClick = { state.removeLayer(layer.id) }, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.Delete, "del", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error) }
        }
    }
}

// ============ PROPERTIES PANEL ============

@Composable
private fun PropertiesPanel(state: EditorState) {
    val layer = state.scene.layers.firstOrNull { it.id == state.selectedLayerId }
    if (layer == null) {
        Text("Select a layer to edit its properties.", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Properties: ${layer.name}", style = MaterialTheme.typography.titleSmall)
        }
        if (layer.type == LayerType.CHARACTER) {
            item { CharacterProps(state, layer) }
        }
        if (layer.type == LayerType.PROP || layer.type == LayerType.EFFECT) {
            item { PropProps(state, layer) }
        }
        if (layer.type == LayerType.TEXT) {
            item { TextProps(state, layer) }
        }
        item { TransformProps(state, layer) }
        item { KeyframeControls(state, layer) }
        item { AnimationPresetsRow(state, layer) }
    }
}

@Composable
private fun CharacterProps(state: EditorState, layer: com.draftstudio.app.model.Layer) {
    val a = layer.appearance
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Character", style = MaterialTheme.typography.labelMedium)
        Row {
            Text("Skin", Modifier.weight(1f).align(Alignment.CenterVertically))
            ColorDotPicker(
                colors = listOf(0xFFFFCCB0, 0xFF8D6E63, 0xFFFFE0B2, 0xFF5D4037, 0xFFFF8A80),
                selected = a.skin.toInt(),
                onPick = { c -> state.setAppearance(layer.id) { it.copy(skin = c) } },
            )
        }
        Row {
            Text("Shirt", Modifier.weight(1f).align(Alignment.CenterVertically))
            ColorDotPicker(
                colors = listOf(0xFF42A5F5, 0xFFEF5350, 0xFF66BB6A, 0xFFFFA726, 0xFFAB47BC, 0xFF78909C),
                selected = a.color.toInt(),
                onPick = { c -> state.setAppearance(layer.id) { it.copy(color = c) } },
            )
        }
        Row {
            Text("Pants", Modifier.weight(1f).align(Alignment.CenterVertically))
            ColorDotPicker(
                colors = listOf(0xFF263238, 0xFF37474F, 0xFF455A64, 0xFF546E7A, 0xFF1A237E),
                selected = a.accent.toInt(),
                onPick = { c -> state.setAppearance(layer.id) { it.copy(accent = c) } },
            )
        }
        Row {
            Text("Emotion", Modifier.weight(1f))
            DropdownPicker(
                value = a.emotion,
                options = listOf("neutral", "happy", "sad", "angry", "surprised", "sleepy"),
                onPick = { v -> state.setAppearance(layer.id) { it.copy(emotion = v) } },
            )
        }
        Row {
            Text("Prop", Modifier.weight(1f))
            DropdownPicker(
                value = a.prop,
                options = listOf("none", "hat", "glasses", "crown", "mic", "sword"),
                onPick = { v -> state.setAppearance(layer.id) { it.copy(prop = v) } },
            )
        }
    }
}

@Composable
private fun PropProps(state: EditorState, layer: com.draftstudio.app.model.Layer) {
    val a = layer.appearance
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Style", style = MaterialTheme.typography.labelMedium)
        Row {
            Text("Shape", Modifier.weight(1f))
            DropdownPicker(
                value = a.prop,
                options = listOf("ball", "box", "tree", "star", "sparkle", "ring", "rays"),
                onPick = { v -> state.setAppearance(layer.id) { it.copy(prop = v) } },
            )
        }
        Row {
            Text("Color", Modifier.weight(1f).align(Alignment.CenterVertically))
            ColorDotPicker(
                colors = listOf(0xFF42A5F5, 0xFFEF5350, 0xFF66BB6A, 0xFFFFA726, 0xFFAB47BC, 0xFFFFFFFF),
                selected = a.color.toInt(),
                onPick = { c -> state.setAppearance(layer.id) { it.copy(color = c) } },
            )
        }
    }
}

@Composable
private fun TextProps(state: EditorState, layer: com.draftstudio.app.model.Layer) {
    val t = layer.text ?: return
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Text", style = MaterialTheme.typography.labelMedium)
        Row {
            Text("Content", Modifier.weight(1f))
            androidx.compose.material3.OutlinedTextField(
                value = t.content,
                onValueChange = { v ->
                    state.scene.layers = state.scene.layers.map {
                        if (it.id == layer.id) it.copy(text = t.copy(content = v)) else it
                    }
                    state.persist()
                },
                singleLine = true,
                modifier = Modifier.weight(2f),
            )
        }
        Row {
            Text("Size", Modifier.weight(1f).align(Alignment.CenterVertically))
            Slider(
                value = t.size,
                onValueChange = { v ->
                    state.scene.layers = state.scene.layers.map {
                        if (it.id == layer.id) it.copy(text = t.copy(size = v)) else it
                    }
                    state.persist()
                },
                valueRange = 12f..160f,
                modifier = Modifier.weight(2f),
            )
        }
    }
}

@Composable
private fun TransformProps(state: EditorState, layer: com.draftstudio.app.model.Layer) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Transform", style = MaterialTheme.typography.labelMedium)
        PropertySlider(state, layer, "X", TrackType.X, -1000f, 1000f, layer.x)
        PropertySlider(state, layer, "Y", TrackType.Y, -1000f, 1000f, layer.y)
        PropertySlider(state, layer, "Scale", TrackType.SCALE_X, 0.1f, 3f, layer.scaleX)
        PropertySlider(state, layer, "Rotation", TrackType.ROTATION, -360f, 360f, layer.rotation)
        PropertySlider(state, layer, "Opacity", TrackType.OPACITY, 0f, 1f, layer.opacity)
    }
}

@Composable
private fun PropertySlider(state: EditorState, layer: com.draftstudio.app.model.Layer, label: String, prop: TrackType, min: Float, max: Float, default: Float) {
    val current = com.draftstudio.app.core.Tracks.valueAt(layer, prop, state.currentFrame, default)
    var display by remember { mutableStateOf(current) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(72.dp), fontSize = 12.sp)
        Slider(
            value = display,
            onValueChange = {
                display = it
                state.setTransformValue(prop, it)
            },
            valueRange = min..max,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun KeyframeControls(state: EditorState, layer: com.draftstudio.app.model.Layer) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Keyframes", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { state.setKeyframeAtPlayhead() }, modifier = Modifier.weight(1f)) { Text("Set Key") }
            Button(onClick = { state.clearKeyframeAtPlayhead() }, modifier = Modifier.weight(1f)) { Text("Clear Key") }
        }
        Text("Ease for new key:", style = MaterialTheme.typography.bodySmall)
        DropdownPicker(
            value = state.selectedEase,
            options = listOf("linear", "easeIn", "easeOut", "easeInOut", "hold"),
            onPick = { state.selectedEase = it },
        )
    }
}

@Composable
private fun AnimationPresetsRow(state: EditorState, layer: com.draftstudio.app.model.Layer) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Animation Presets", style = MaterialTheme.typography.labelMedium)
        Presets.all.chunked(2).forEach { rowPresets ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowPresets.forEach { preset ->
                    Button(
                        onClick = { state.applyPreset(preset.name, state.currentFrame.toInt(), 1.2f) },
                        modifier = Modifier.weight(1f),
                    ) { Text(preset.name, fontSize = 10.sp, maxLines = 2) }
                }
            }
        }
    }
}

// ============ SCENES PANEL ============

@Composable
private fun ScenesPanel(state: EditorState) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { state.addScene() }, modifier = Modifier.weight(1f)) { Text("+ Scene") }
            Button(onClick = { state.duplicateScene() }, modifier = Modifier.weight(1f)) { Text("Duplicate") }
            Button(onClick = { state.deleteScene() }, modifier = Modifier.weight(1f)) { Text("Delete") }
        }
        Spacer(Modifier.height(12.dp))
        Text("Scenes", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(state.project.scenes, key = { it.id }) { s ->
                Card(onClick = {
                    val idx = state.project.scenes.indexOfFirst { it.id == s.id }
                    state.currentSceneIndex = idx
                    state.seek(0f)
                }) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (s.id == state.scene.id) "▶ " else "  " + s.name, fontSize = 13.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${s.durationSeconds}s · ${s.layers.size} layers", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Scene duration (seconds)", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = state.scene.durationSeconds,
            onValueChange = { state.setSceneDuration(it) },
            valueRange = 1f..60f,
        )
    }
}

// ============ TIMELINE ============

@Composable
private fun TimelineBar(state: EditorState) {
    val total = Timeline.totalFrames(state.scene)
    Surface(tonalElevation = 3.dp) {
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (state.playing) state.stop() else { state.playing = true }
                }, modifier = Modifier.size(36.dp)) {
                    Icon(if (state.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                }
                Text("Time", fontSize = 11.sp)
                Spacer(Modifier.width(8.dp))
                Text("${state.currentFrame.toInt()}/${total}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(4.dp))
            // frame ruler + keyframe diamonds
            Row(Modifier.fillMaxWidth().height(44.dp)) {
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    ComposeCanvas(modifier = Modifier.fillMaxSize()) {
                        // tick marks every 10 frames
                        val step = size.width / total.toFloat()
                        repeat(total / 10 + 1) { i ->
                            val x = i * 10 * step
                            drawLine(Color.Gray.copy(alpha = 0.5f), androidx.compose.ui.geometry.Offset(x, 0f), androidx.compose.ui.geometry.Offset(x, if (i % 3 == 0) 8f else 4f), strokeWidth = 1f)
                            if (i % 3 == 0) {
                                drawContext.canvas.nativeCanvas.drawText((i * 10).toString(), x + 2f, 16f, android.graphics.Paint().apply { color = android.graphics.Color.LTGRAY; textSize = 10f })
                            }
                        }
                        // selected layer keyframes
                        val layer = state.scene.layers.firstOrNull { it.id == state.selectedLayerId }
                        if (layer != null) {
                            for (t in layer.tracks) {
                                for (k in t.keyframes) {
                                    val kx = k.frame * step
                                    drawCircle(Color(0xFFFFD54F), radius = 5f, center = androidx.compose.ui.geometry.Offset(kx, 18f))
                                }
                            }
                        }
                        // playhead
                        val px = state.currentFrame * step
                        drawLine(Color.White, androidx.compose.ui.geometry.Offset(px, 0f), androidx.compose.ui.geometry.Offset(px, size.height), strokeWidth = 2f)
                    }
                }
            }
        }
    }
}

// ============ shared widgets ============

@Composable
fun ColorDotPicker(colors: List<Int>, selected: Int, onPick: (Long) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        colors.forEach { c ->
            val isSel = c == selected
            androidx.compose.foundation.clickable(
                onClick = { onPick(c.toLong()) }
            ) {
                Box(
                    Modifier
                        .size(if (isSel) 22.dp else 18.dp)
                        .background(Color(c))
                )
            }
        }
    }
}

@Composable
fun DropdownPicker(value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }) {
            Text(value, fontSize = 12.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o ->
                DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false })
            }
        }
    }
}

// helpers on EditorState used by panels (defined in EditorState.kt)
