package com.draftstudio.app.ui

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.draftstudio.app.core.Commands
import com.draftstudio.app.core.Presets
import com.draftstudio.app.core.ProjectStore
import com.draftstudio.app.core.Timeline
import com.draftstudio.app.model.Layer
import com.draftstudio.app.model.Project
import com.draftstudio.app.model.Scene
import kotlinx.coroutines.delay

/**
 * Holds the state of the open project while editing.
 * UI reads [project] and calls commands; every change saves to disk.
 */
class EditorState(private val appContext: Context, initial: Project) {

    var project by mutableStateOf(initial)
        private set

    var currentSceneIndex by mutableIntStateOf(0)

    /** Playback head in frames (float for smooth scrubbing). */
    var currentFrame by mutableFloatStateOf(0f)
        private set

    var playing by mutableStateOf(false)
        private set

    var selectedLayerId by mutableStateOf<String?>()
        private set

    var selectedProperty by mutableStateOf<com.draftstudio.app.model.TrackType?>()
        private set

    var selectedEase by mutableStateOf("linear")

    val scene: Scene get() = project.scenes[currentSceneIndex.coerceIn(0, project.scenes.size - 1)]

    fun selectLayer(id: String?) { selectedLayerId = id }
    fun selectProperty(t: com.draftstudio.app.model.TrackType?) { selectedProperty = t }

    /** Set keyframes for all transform properties at the playhead. */
    fun setKeyframeAtPlayhead() {
        val id = selectedLayerId ?: return
        val layer = scene.layers.firstOrNull { it.id == id } ?: return
        val frame = currentFrame.toInt()
        val x = com.draftstudio.app.core.Tracks.valueAt(layer, com.draftstudio.app.model.TrackType.X, currentFrame, layer.x)
        val y = com.draftstudio.app.core.Tracks.valueAt(layer, com.draftstudio.app.model.TrackType.Y, currentFrame, layer.y)
        val sx = com.draftstudio.app.core.Tracks.valueAt(layer, com.draftstudio.app.model.TrackType.SCALE_X, currentFrame, layer.scaleX)
        val sy = com.draftstudio.app.core.Tracks.valueAt(layer, com.draftstudio.app.model.TrackType.SCALE_Y, currentFrame, layer.scaleY)
        val rot = com.draftstudio.app.core.Tracks.valueAt(layer, com.draftstudio.app.model.TrackType.ROTATION, currentFrame, layer.rotation)
        val op = com.draftstudio.app.core.Tracks.valueAt(layer, com.draftstudio.app.model.TrackType.OPACITY, currentFrame, layer.opacity)
        val lip = com.draftstudio.app.core.Tracks.valueAt(layer, com.draftstudio.app.model.TrackType.LIP, currentFrame, layer.appearance.lipOpen)
        Commands.setKeyframe(scene, id, com.draftstudio.app.model.TrackType.X, frame, x, selectedEase)
        Commands.setKeyframe(scene, id, com.draftstudio.app.model.TrackType.Y, frame, y, selectedEase)
        Commands.setKeyframe(scene, id, com.draftstudio.app.model.TrackType.SCALE_X, frame, sx, selectedEase)
        Commands.setKeyframe(scene, id, com.draftstudio.app.model.TrackType.SCALE_Y, frame, sy, selectedEase)
        Commands.setKeyframe(scene, id, com.draftstudio.app.model.TrackType.ROTATION, frame, rot, selectedEase)
        Commands.setKeyframe(scene, id, com.draftstudio.app.model.TrackType.OPACITY, frame, op, selectedEase)
        Commands.setKeyframe(scene, id, com.draftstudio.app.model.TrackType.LIP, frame, lip, selectedEase)
        persist()
    }

    fun clearKeyframeAtPlayhead() {
        val id = selectedLayerId ?: return
        val frame = currentFrame.toInt()
        com.draftstudio.app.model.TrackType.entries.forEach { t ->
            Commands.removeKeyframe(scene, id, t, frame)
        }
        persist()
    }

    fun addPropLayer() {
        addLayer(
            Layer(
                id = "layer_${System.currentTimeMillis()}",
                name = "Prop",
                type = com.draftstudio.app.model.LayerType.PROP,
                appearance = com.draftstudio.app.model.Appearance(
                    character = false,
                    color = 0xFF66BB6A,
                    prop = "ball",
                ),
            )
        )
    }

    fun addTextLayer() {
        addLayer(
            Layer(
                id = "layer_${System.currentTimeMillis()}",
                name = "Text",
                type = com.draftstudio.app.model.LayerType.TEXT,
                text = com.draftstudio.app.model.TextAppearance(content = "Hello!", size = 48f),
            )
        )
    }

    fun addEffectLayer() {
        addLayer(
            Layer(
                id = "layer_${System.currentTimeMillis()}",
                name = "Effect",
                type = com.draftstudio.app.model.LayerType.EFFECT,
                appearance = com.draftstudio.app.model.Appearance(
                    character = false,
                    color = 0xFFFFD54F,
                    prop = "sparkle",
                ),
            )
        )
    }

    fun addLayer(layer: Layer) {
        val s = scene
        Commands.addLayer(s, layer)
        selectedLayerId = layer.id
        persist()
    }

    fun removeLayer(id: String) {
        Commands.removeLayer(scene, id)
        if (selectedLayerId == id) selectedLayerId = null
        persist()
    }

    fun duplicateLayer(id: String) {
        Commands.duplicateLayer(scene, id)
        persist()
    }

    fun moveLayer(id: String, dir: Int) {
        Commands.reorderLayer(scene, id, dir)
        persist()
    }

    fun toggleVisible(id: String) { Commands.toggleVisible(scene, id); persist() }
    fun toggleLock(id: String) { Commands.toggleLock(scene, id); persist() }

    fun setOpacity(id: String, v: Float) { Commands.setOpacity(scene, id, v); persist() }

    fun setAppearance(id: String, transform: (com.draftstudio.app.model.Appearance) -> com.draftstudio.app.model.Appearance) {
        Commands.setAppearance(scene, id, transform)
        persist()
    }

    fun setKeyframe(property: com.draftstudio.app.model.TrackType, value: Float, ease: String = "linear") {
        val id = selectedLayerId ?: return
        Commands.setKeyframe(scene, id, property, currentFrame.toInt(), value, ease)
        persist()
    }

    fun removeKeyframe(property: com.draftstudio.app.model.TrackType, frame: Int) {
        val id = selectedLayerId ?: return
        Commands.removeKeyframe(scene, id, property, frame)
        persist()
    }

    /**
     * Change a transform property live. If the layer has a track for the
     * property, writes a keyframe at the playhead; otherwise updates the
     * static base value so the change is visible immediately.
     */
    fun setTransformValue(property: com.draftstudio.app.model.TrackType, value: Float) {
        val id = selectedLayerId ?: return
        val layer = scene.layers.firstOrNull { it.id == id } ?: return
        val hasTrack = layer.tracks.any { it.property == property }
        if (hasTrack) {
            Commands.setKeyframe(scene, id, property, currentFrame.toInt(), value, selectedEase)
        } else {
            scene.layers = scene.layers.map {
                if (it.id != id) it
                else when (property) {
                    com.draftstudio.app.model.TrackType.X -> it.copy(x = value)
                    com.draftstudio.app.model.TrackType.Y -> it.copy(y = value)
                    com.draftstudio.app.model.TrackType.SCALE_X -> it.copy(scaleX = value)
                    com.draftstudio.app.model.TrackType.SCALE_Y -> it.copy(scaleY = value)
                    com.draftstudio.app.model.TrackType.ROTATION -> it.copy(rotation = value)
                    com.draftstudio.app.model.TrackType.OPACITY -> it.copy(opacity = value)
                    com.draftstudio.app.model.TrackType.LIP -> it.copy(appearance = it.appearance.copy(lipOpen = value))
                    else -> it
                }
            }
        }
        persist()
    }

    fun clearTrack(property: com.draftstudio.app.model.TrackType) {
        val id = selectedLayerId ?: return
        Commands.clearTrack(scene, id, property)
        persist()
    }

    fun applyPreset(presetName: String, startFrame: Int, duration: Float) {
        val preset = Presets.byName(presetName) ?: return
        val id = selectedLayerId ?: return
        Commands.applyPreset(scene, id, preset, startFrame, duration)
        persist()
    }

    fun setSceneDuration(seconds: Float) {
        scene.durationSeconds = seconds.coerceIn(0.2f, 120f)
        persist()
    }

    fun setBackground(type: String, colorTop: Long, colorBottom: Long, seed: Int) {
        val s = scene
        s.background = s.background.copy(
            type = type,
            colorTop = colorTop,
            colorBottom = colorBottom,
            seed = seed,
        )
        persist()
    }

    fun setCameraKeyframe() {
        Commands.setCameraKeyframe(scene, currentFrame.toInt())
        persist()
    }

    fun removeCameraKeyframe(frame: Int) {
        Commands.removeCameraKeyframe(scene, frame)
        persist()
    }

    fun seek(frame: Float) {
        val max = Timeline.totalFrames(scene).toFloat()
        currentFrame = frame.coerceIn(0f, max)
    }

    /** Playback loop; call from a coroutine. */
    suspend fun playLoop() {
        playing = true
        while (playing) {
            val max = Timeline.totalFrames(scene).toFloat()
            currentFrame += 1f
            if (currentFrame >= max) currentFrame = 0f
            delay((1000f / 30f).toLong())
        }
    }

    fun stop() { playing = false }

    fun addScene() {
        val scenes = project.scenes.toMutableList()
        val s = Scene(
            id = "scene_${System.currentTimeMillis()}",
            name = "Scene ${scenes.size + 1}",
            durationSeconds = 10f,
            camera = com.draftstudio.app.model.Camera(width = project.width, height = project.height),
        )
        scenes.add(s)
        project = project.copy(scenes = scenes)
        currentSceneIndex = scenes.size - 1
        persist()
    }

    fun duplicateScene() {
        project = Commands.duplicateScene(project, scene.id)
        persist()
    }

    fun deleteScene() {
        val old = project
        project = Commands.deleteScene(project, scene.id)
        if (project.scenes.size != old.scenes.size) {
            currentSceneIndex = 0
            persist()
        }
    }

    fun renameScene(name: String) {
        project = Commands.renameScene(project, scene.id, name)
        persist()
    }

    fun persist() {
        val updated = project.copy(updatedAt = System.currentTimeMillis())
        project = updated
        ProjectStore.save(appContext, updated)
    }
}
