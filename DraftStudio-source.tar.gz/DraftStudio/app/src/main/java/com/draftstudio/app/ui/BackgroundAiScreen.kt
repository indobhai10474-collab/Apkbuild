package com.draftstudio.app.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp

/**
 * On-device AI background generator: procedural landscapes/skies/stars
 * generated from a seed — deterministic and free.
 */
@Composable
fun BackgroundAiScreen(onDone: (String, Long, Long, Int) -> Unit, onBack: () -> Unit) {
    var type by remember { mutableStateOf("gradient") }
    var top by remember { mutableStateOf(0xFFB3E5FCL) }
    var bottom by remember { mutableStateOf(0xFF1A237EL) }
    var seed by remember { mutableStateOf((Math.random() * 100000).toInt()) }

    Scaffold(
        topBar = {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "back") }
                Text("AI Background Generator", style = MaterialTheme.typography.titleMedium)
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner).padding(16.dp)) {
            // live preview
            val bmp = remember(type, top, bottom, seed) {
                val b = Bitmap.createBitmap(320, 180, Bitmap.Config.ARGB_8888)
                val c = Canvas(b)
                com.draftstudio.app.render.SceneRenderer.drawBackground(
                    c,
                    com.draftstudio.app.model.SceneBackground(
                        type = type, colorTop = top, colorBottom = bottom, seed = seed
                    ),
                    320f, 180f
                )
                b.asImageBitmap()
            }
            Box(
                Modifier.fillMaxWidth().height(220.dp).background(Color(0xFF0A0914)),
                contentAlignment = Alignment.Center,
            ) {
                Image(bmp, null, Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                listOf("gradient", "stars", "mountains", "solid").forEach { t ->
                    TextButton(onClick = { type = t }) {
                        Text(t, color = if (type == t) MaterialTheme.colorScheme.primary else Color.Gray)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Sky color (top)", style = MaterialTheme.typography.bodySmall)
            Row {
                listOf(0xFFB3E5FCL, 0xFFFFCDD2L, 0xFFC8E6C9L, 0xFFFFF9C4L, 0xFFD1C4E9L, 0xFFBBDEFBL).forEach { c ->
                    Box(Modifier.size(28.dp).padding(4.dp).background(Color(c)).clickable { top = c })
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Ground color (bottom)", style = MaterialTheme.typography.bodySmall)
            Row {
                listOf(0xFF1A237EL, 0xFF4E342EL, 0xFF1B5E20L, 0xFF212121L, 0xFF37474FL, 0xFF283593L).forEach { c ->
                    Box(Modifier.size(28.dp).padding(4.dp).background(Color(c)).clickable { bottom = c })
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onDone(type, top, bottom, seed) }, modifier = Modifier.fillMaxWidth()) {
                Text("Use as Scene Background")
            }
            TextButton(onClick = { seed = (Math.random() * 100000).toInt() }) { Text("🎲 Randomize landscape") }
        }
    }
}
