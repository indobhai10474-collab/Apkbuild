package com.draftstudio.app.export

import com.draftstudio.app.core.ProjectStore
import com.draftstudio.app.core.VoiceClip
import java.io.File
import java.io.OutputStream

/**
 * Mixes multiple voice clips onto a timeline into one PCM stream
 * (44100 Hz mono 16-bit). Used when exporting video with narration.
 */
object AudioMixer {

    data class ClipPlacement(val clip: VoiceClip, val startSeconds: Float)

    fun mix(root: File, placements: List<ClipPlacement>, durationSeconds: Float): ByteArray {
        val sampleRate = 44100
        val totalSamples = (durationSeconds * sampleRate).toInt().coerceAtLeast(1)
        val mix = ShortArray(totalSamples)
        for (p in placements) {
            val pcm = ProjectStore.loadVoice(root, p.clip) ?: continue
            val samples = pcm.size / 2
            val startSample = (p.startSeconds * sampleRate).toInt().coerceAtLeast(0)
            for (i in 0 until samples) {
                val idx = startSample + i
                if (idx >= totalSamples) break
                val v = shortAt(pcm, i)
                val old = mix[idx].toInt()
                mix[idx] = ((old + v).coerceIn(-32768, 32767)).toShort()
            }
        }
        val out = ByteArray(totalSamples * 2)
        for (i in mix.indices) {
            out[i * 2] = (mix[i].toInt() and 0xFF).toByte()
            out[i * 2 + 1] = ((mix[i].toInt() shr 8) and 0xFF).toByte()
        }
        return out
    }

    fun writeWav(pcm: ByteArray, out: OutputStream) {
        com.draftstudio.app.ai.WavWriter.write(pcm, out, 44100)
    }

    private fun shortAt(pcm: ByteArray, i: Int): Int {
        val b0 = pcm[i * 2].toInt() and 0xFF
        val b1 = pcm[i * 2 + 1].toInt() and 0xFF
        return (b0 or (b1 shl 8)).toShort().toInt()
    }
}
