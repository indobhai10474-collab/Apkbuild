package com.draftstudio.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.draftstudio.app.ai.TtsEngine
import com.draftstudio.app.core.ProjectStore
import com.draftstudio.app.core.VoiceClip
import java.io.File

/**
 * AI Voiceover: on-device text-to-speech with lip-sync bake.
 * No network, no credits — unlimited voiceovers.
 */
@Composable
fun VoiceoverScreen(tts: TtsEngine, root: File, onBack: () -> Unit, onClip: (VoiceClip) -> Unit) {
    var text by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf(1f) }
    var pitch by remember { mutableStateOf(1f) }
    var busy by remember { mutableStateOf(false) }
    var lastClip by remember { mutableStateOf<VoiceClip?>() }

    // list of existing clips
    val clips = remember(root) { listVoiceClips(root) }

    Scaffold(
        topBar = {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "back") }
                Text("AI Voiceover (on-device)", style = MaterialTheme.typography.titleMedium)
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner).padding(16.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Enter dialogue / narration") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
            )
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Speed", Modifier.width(56.dp))
                Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.5f..1.8f, modifier = Modifier.weight(1f))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Pitch", Modifier.width(56.dp))
                Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.5f..1.8f, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    if (text.isBlank() || busy) return@Button
                    busy = true
                    tts.synthesize(text.trim(), rate, pitch) { clip ->
                        busy = false
                        lastClip = clip
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (busy) "Synthesizing…" else "Generate Voiceover") }
            lastClip?.let { clip ->
                Spacer(Modifier.height(8.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Ready: \"${clip.text.take(48)}\"", style = MaterialTheme.typography.bodyMedium)
                        Text("${clip.durationSeconds}s", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { tts.play(root, clip) }) { Icon(Icons.Default.PlayArrow, null) }
                            Button(onClick = { onClip(clip) }) { Text("Add to Scene") }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Existing voice clips", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            if (clips.isEmpty()) {
                Text("No voice clips yet. Generate one above.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(clips, key = { it.id }) { clip ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(clip.text.take(40), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                IconButton(onClick = { tts.play(root, clip) }) { Icon(Icons.Default.PlayArrow, null) }
                                TextButton(onClick = { onClip(clip) }) { Text("Add") }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun listVoiceClips(root: File): List<VoiceClip> {
    // voice clips are saved as .pcm + JSON sidecar not stored; we rebuild from layer usage.
    // For simplicity, list pcm files with names as pseudo clips.
    val dir = ProjectStore.voiceDir(root)
    return dir.listFiles()?.filter { it.extension == "pcm" }
        ?.map { f ->
            VoiceClip(
                id = f.name,
                text = f.name.removePrefix("voice_").removeSuffix(".pcm"),
                fileName = f.name,
                durationSeconds = f.length() / 2f / 44100f,
            )
        }
        ?.sortedByDescending { it.fileName } ?: emptyList()
}
