package com.draftstudio.app.ui

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.draftstudio.app.core.ProjectStore
import com.draftstudio.app.model.Project
import com.draftstudio.app.model.Scene
import com.draftstudio.app.ai.TtsEngine

enum class Screen { HOME, EDITOR, CHARACTER_AI, BACKGROUND_AI, VOICEOVER, EXPORT }

@Composable
fun DraftStudioApp() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf(Screen.HOME) }
    var projectId by remember { mutableStateOf<String?>() }
    var currentProject by remember { mutableStateOf<Project?>() }

    // TTS engine lives for the whole session
    val tts = remember { TtsEngine(context) }
    DisposableEffect(Unit) {
        onDispose { tts.shutdown() }
    }

    fun openProject(p: Project) {
        currentProject = p
        projectId = p.id
        screen = Screen.EDITOR
    }

    when (screen) {
        Screen.HOME -> HomeScreen(
            projects = ProjectStore.list(context.filesDir),
            onOpen = { openProject(it) },
            onNew = {
                val p = newProject(context)
                ProjectStore.save(context.filesDir, p)
                openProject(p)
            },
            onDelete = { p ->
                ProjectStore.delete(context.filesDir, p.id)
                screen = Screen.HOME
            },
        )
        Screen.EDITOR -> {
            val p = currentProject
            if (p != null) {
                val state = remember(currentProject) { EditorState(context, p) }
                EditorScreen(
                    state = state,
                    onBack = { screen = Screen.HOME },
                    onCharacterAI = { screen = Screen.CHARACTER_AI },
                    onBackgroundAI = { screen = Screen.BACKGROUND_AI },
                    onVoiceover = { screen = Screen.VOICEOVER },
                    onExport = { screen = Screen.EXPORT },
                )
            }
        }
        Screen.CHARACTER_AI -> CharacterAiScreen(
            onDone = { appearance, name ->
                val p = currentProject ?: return@CharacterAiScreen
                val state = EditorState(context, p)
                state.addLayer(
                    com.draftstudio.app.model.Layer(
                        id = "layer_${System.currentTimeMillis()}",
                        name = name,
                        type = com.draftstudio.app.model.LayerType.CHARACTER,
                        appearance = appearance,
                    )
                )
                currentProject = state.project
                screen = Screen.EDITOR
            },
            onBack = { screen = Screen.EDITOR },
        )
        Screen.BACKGROUND_AI -> BackgroundAiScreen(
            onDone = { type, top, bottom, seed ->
                val p = currentProject ?: return@BackgroundAiScreen
                val state = EditorState(context, p)
                state.setBackground(type, top, bottom, seed)
                currentProject = state.project
                screen = Screen.EDITOR
            },
            onBack = { screen = Screen.EDITOR },
        )
        Screen.VOICEOVER -> VoiceoverScreen(
            tts = tts,
            root = context.filesDir,
            onBack = { screen = Screen.EDITOR },
            onClip = { clip ->
                val p = currentProject ?: return@VoiceoverScreen
                val state = EditorState(context, p)
                // If a character layer is selected, auto bake lip-sync from the PCM
                val charLayer = state.selectedLayerId?.let { id ->
                    state.scene.layers.firstOrNull { it.id == id && it.type == com.draftstudio.app.model.LayerType.CHARACTER }
                }
                val lipKfs = charLayer?.let { layer ->
                    val pcm = com.draftstudio.app.core.ProjectStore.loadVoice(context.filesDir, clip)
                    if (pcm != null) {
                        com.draftstudio.app.ai.LipSync.bakeKeyframes(
                            com.draftstudio.app.ai.LipSync.analyze(pcm, 30),
                            state.currentFrame.toInt(),
                            30
                        )
                    } else null
                }
                if (charLayer != null && lipKfs != null && lipKfs.isNotEmpty()) {
                    // Replace the character's LIP track with baked lip-sync keyframes.
                    state.scene.layers = state.scene.layers.map {
                        if (it.id != charLayer.id) it
                        else {
                            val track = com.draftstudio.app.model.Track(
                                id = "track_lip_${System.currentTimeMillis()}",
                                property = com.draftstudio.app.model.TrackType.LIP,
                                keyframes = lipKfs,
                            )
                            it.copy(tracks = it.tracks.filterNot { t -> t.property == com.draftstudio.app.model.TrackType.LIP } + track)
                        }
                    }
                    state.persist()
                }
                val audioLayer = com.draftstudio.app.model.Layer(
                    id = "layer_${System.currentTimeMillis()}",
                    name = "Voiceover: ${clip.text.take(24)}",
                    type = com.draftstudio.app.model.LayerType.AUDIO,
                )
                audioLayer.appearance.prop = clip.fileName
                state.addLayer(audioLayer)
                currentProject = state.project
            },
        )
        Screen.EXPORT -> ExportScreen(
            project = currentProject,
            onBack = { screen = Screen.EDITOR },
        )
    }
}

fun newProject(context: Context): Project {
    val now = System.currentTimeMillis()
    val id = "proj_$now"
    val scene = Scene(
        id = "scene_$now",
        name = "Scene 1",
        durationSeconds = 10f,
        camera = com.draftstudio.app.model.Camera(width = 1280, height = 720),
    )
    return Project(
        id = id,
        name = "My Project ${(now % 10000)}",
        width = 1280,
        height = 720,
        fps = 30,
        scenes = listOf(scene),
    )
}
